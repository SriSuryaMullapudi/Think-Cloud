<?php
declare(strict_types=1);


namespace OCA\Talk\Exceptions;

class UnauthorizedException extends \Exception {

}
