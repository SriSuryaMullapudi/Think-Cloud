<?php
declare(strict_types=1);


namespace OCA\Talk\Exceptions;

class RoomNotFoundException extends \OutOfBoundsException {

}
