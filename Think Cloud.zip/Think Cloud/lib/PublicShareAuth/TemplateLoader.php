<?php
declare(strict_types=1);

namespace OCA\Talk\PublicShareAuth;

use OCP\EventDispatcher\IEventDispatcher;
use OCP\Share\IShare;
use OCP\Util;
use Symfony\Component\EventDispatcher\GenericEvent;


class TemplateLoader {

	public static function register(IEventDispatcher $dispatcher): void {
		$listener = function(GenericEvent $event) {
			/** @var IShare $share */
			$share = $event->getArgument('share');
			self::loadRequestPasswordByTalkUi($share);
		};
		$dispatcher->addListener('OCA\Files_Sharing::loadAdditionalScripts::publicShareAuth', $listener);
	}

	
	public static function loadRequestPasswordByTalkUi(IShare $share): void {
		if (!$share->getSendPasswordByTalk()) {
			return;
		}

		Util::addStyle('spreed', 'merged-share-auth');
		Util::addScript('spreed', 'merged-share-auth');
	}

}
