<?php
declare(strict_types=1);

namespace OCA\Talk\PublicShareAuth;

use OCA\Talk\Events\JoinRoomGuestEvent;
use OCA\Talk\Events\JoinRoomUserEvent;
use OCA\Talk\Events\RoomEvent;
use OCA\Talk\Exceptions\ParticipantNotFoundException;
use OCA\Talk\Participant;
use OCA\Talk\Room;
use OCP\EventDispatcher\IEventDispatcher;


class Listener {

	public static function register(IEventDispatcher $dispatcher): void {
		$listener = static function(JoinRoomUserEvent $event) {
			self::preventExtraUsersFromJoining($event->getRoom(), $event->getUser()->getUID());
		};
		$dispatcher->addListener(Room::EVENT_BEFORE_ROOM_CONNECT, $listener);

		$listener = static function(JoinRoomGuestEvent $event) {
			self::preventExtraGuestsFromJoining($event->getRoom());
		};
		$dispatcher->addListener(Room::EVENT_BEFORE_GUEST_CONNECT, $listener);

		$listener = static function(RoomEvent $event) {
			self::destroyRoomOnParticipantLeave($event->getRoom());
		};
		$dispatcher->addListener(Room::EVENT_AFTER_USER_REMOVE, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_PARTICIPANT_REMOVE, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_ROOM_DISCONNECT, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_GUESTS_CLEAN, $listener);
	}

	
	public static function preventExtraUsersFromJoining(Room $room, string $userId): void {
		if ($room->getObjectType() !== 'share:password') {
			return;
		}

		try {
			$participant = $room->getParticipant($userId);
			if ($participant->getParticipantType() === Participant::OWNER) {
				return;
			}
		} catch (ParticipantNotFoundException $e) {
		}

		if ($room->getActiveGuests() > 0 || \count($room->getParticipantUserIds()) > 1) {
			throw new \OverflowException('Only the owner and another participant are allowed in rooms to request the password for a share');
		}
	}

		public static function preventExtraGuestsFromJoining(Room $room): void {
		if ($room->getObjectType() !== 'share:password') {
			return;
		}

		if ($room->getActiveGuests() > 0 || \count($room->getParticipantUserIds()) > 1) {
			throw new \OverflowException('Only the owner and another participant are allowed in rooms to request the password for a share');
		}
	}

	
	public static function destroyRoomOnParticipantLeave(Room $room): void {
		if ($room->getObjectType() !== 'share:password') {
			return;
		}

		$room->deleteRoom();
	}

}
