<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Room;

class VerifyRoomPasswordEvent extends RoomEvent {

	
	protected $password;
		protected $isPasswordValid;
	
	protected $redirectUrl = '';


	public function __construct(Room $room,
								string $password) {
		parent::__construct($room);
		$this->password = $password;
	}

	public function getPassword(): string {
		return $this->password;
	}

	public function setIsPasswordValid(bool $isPasswordValid): void {
		$this->isPasswordValid = $isPasswordValid;
	}

	public function isPasswordValid(): ?bool {
		return $this->isPasswordValid;
	}

	public function setRedirectUrl(string $redirectUrl): void {
		$this->redirectUrl = $redirectUrl;
	}

	public function getRedirectUrl(): string {
		return $this->redirectUrl;
	}
}
