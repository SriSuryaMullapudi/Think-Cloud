<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Participant;
use OCA\Talk\Room;
use OCP\IUser;

class RemoveUserEvent extends RemoveParticipantEvent {

	
	protected $user;


	public function __construct(Room $room,
								Participant $participant,
								IUser $user,
								string $reason) {
		parent::__construct($room, $participant, $reason);
		$this->user = $user;
	}

	public function getUser(): IUser {
		return $this->user;
	}
}
