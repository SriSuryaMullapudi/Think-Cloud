<?php
declare(strict_types=1);
namespace OCA\Talk\Events;


use OCA\Talk\Room;
use OCP\EventDispatcher\Event;

class RoomEvent extends Event {

	
	protected $room;


	public function __construct(Room $room) {
		parent::__construct();
		$this->room = $room;
	}

	
	public function getRoom(): Room {
		return $this->room;
	}
}
