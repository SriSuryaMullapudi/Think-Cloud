<?php
declare(strict_types=1);
namespace OCA\Talk\Events;


use OCA\Talk\Model\Command;
use OCA\Talk\Room;
use OCP\Comments\IComment;

class CommandEvent extends ChatEvent {

	
	protected $command;
	
	protected $arguments;
	
	protected $output;


	public function __construct(Room $room, IComment $message, Command $command, string $arguments) {
		parent::__construct($room, $message);
		$this->command = $command;
		$this->arguments = $arguments;
	}

	public function getCommand(): Command {
		return $this->command;
	}

	public function getArguments(): string {
		return $this->arguments;
	}

	public function setOutput(string $output): void {
		$this->output = $output;
	}

	public function getOutput(): string {
		return $this->output;
	}
}
