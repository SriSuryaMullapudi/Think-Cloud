<?php
declare(strict_types=1);


namespace OCA\Talk\Events;


use OCA\Talk\Participant;
use OCA\Talk\Room;

class ParticipantEvent extends RoomEvent {

	
	protected $participant;


	public function __construct(Room $room,
								Participant $participant) {
		parent::__construct($room);
		$this->participant = $participant;
	}

	public function getParticipant(): Participant {
		return $this->participant;
	}
}
