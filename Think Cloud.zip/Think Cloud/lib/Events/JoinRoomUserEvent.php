<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Room;
use OCP\IUser;

class JoinRoomUserEvent extends RoomEvent {

	
	protected $user;
		protected $cancelJoin;
	
	protected $password;
	
	protected $passedPasswordProtection;


	public function __construct(Room $room,
								IUser $user,
								string $password,
								bool $passedPasswordProtection) {
		parent::__construct($room);
		$this->cancelJoin = false;
		$this->user = $user;
		$this->password = $password;
		$this->passedPasswordProtection = $passedPasswordProtection;
	}

	public function setCancelJoin(bool $cancelJoin): void {
		$this->cancelJoin = $cancelJoin;
	}

	public function getCancelJoin(): bool {
		return $this->cancelJoin;
	}

	public function getUser(): IUser {
		return $this->user;
	}

	public function getPassword(): string {
		return $this->password;
	}

	public function setPassedPasswordProtection(bool $passedPasswordProtection): void {
		$this->passedPasswordProtection = $passedPasswordProtection;
	}

	public function getPassedPasswordProtection(): bool {
		return $this->passedPasswordProtection;
	}

}
