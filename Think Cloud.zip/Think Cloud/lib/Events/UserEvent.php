<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCP\EventDispatcher\Event;

class UserEvent extends Event {

	
	protected $userId;


	public function __construct(string $userId) {
		parent::__construct();
		$this->userId = $userId;
	}

	public function getUserId(): string {
		return $this->userId;
	}
}
