<?php
declare(strict_types=1);


namespace OCA\Talk\Events;


use OCA\Talk\Participant;
use OCA\Talk\Room;

class RemoveParticipantEvent extends ParticipantEvent {

	
	protected $reason;

	public function __construct(Room $room,
								Participant $participant,
								string $reason) {
		parent::__construct($room, $participant);
		$this->reason = $reason;
	}

	public function getReason(): string {
		return $this->reason;
	}
}
