<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Participant;
use OCA\Talk\Room;

class SignalingEvent extends ParticipantEvent {

	
	protected $action;
	
	protected $session;

	public function __construct(Room $room,
								Participant $participant,
								string $action) {
		parent::__construct($room, $participant);
		$this->action = $action;
		$this->session = '';
	}

	public function getAction(): string {
		return $this->action;
	}

	public function setSession($session): void {
		$this->session = $session;
	}

	public function getSession() {
		return $this->session;
	}
}
