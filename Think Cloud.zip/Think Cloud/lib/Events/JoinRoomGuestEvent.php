<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Room;

class JoinRoomGuestEvent extends RoomEvent {

		protected $cancelJoin;
		protected $password;
	
	protected $passedPasswordProtection;


	public function __construct(Room $room,
								string $password,
								bool $passedPasswordProtection) {
		parent::__construct($room);
		$this->cancelJoin = false;
		$this->password = $password;
		$this->passedPasswordProtection = $passedPasswordProtection;
	}

	public function setCancelJoin(bool $cancelJoin): void {
		$this->cancelJoin = $cancelJoin;
	}

	public function getCancelJoin(): bool {
		return $this->cancelJoin;
	}

	public function getPassword(): string {
		return $this->password;
	}

	public function setPassedPasswordProtection(bool $passedPasswordProtection): void {
		$this->passedPasswordProtection = $passedPasswordProtection;
	}

	public function getPassedPasswordProtection(): bool {
		return $this->passedPasswordProtection;
	}

}
