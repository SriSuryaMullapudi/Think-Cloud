<?php
declare(strict_types=1);


namespace OCA\Talk\Events;


use OCA\Talk\Participant;
use OCA\Talk\Room;

class ModifyParticipantEvent extends ParticipantEvent {

	
	protected $parameter;
	
	protected $newValue;
	
	protected $oldValue;


	public function __construct(Room $room,
								Participant $participant,
								string $parameter,
								$newValue,
								$oldValue = null) {
		parent::__construct($room, $participant);
		$this->parameter = $parameter;
		$this->newValue = $newValue;
		$this->oldValue = $oldValue;
	}

	
	public function getParameter(): string {
		return $this->parameter;
	}

	
	public function getNewValue() {
		return $this->newValue;
	}

	
	public function getOldValue() {
		return $this->oldValue;
	}
}
