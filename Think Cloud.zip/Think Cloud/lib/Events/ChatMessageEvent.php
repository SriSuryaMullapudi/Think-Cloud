<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Model\Message;

class ChatMessageEvent extends ChatEvent {

	
	protected $message;


	public function __construct(Message $message) {
		parent::__construct($message->getRoom(), $message->getComment());
		$this->message = $message;
	}

	public function getMessage(): Message {
		return $this->message;
	}
}
