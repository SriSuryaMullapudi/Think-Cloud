<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Participant;
use OCA\Talk\Room;
use OCP\Comments\IComment;

class ChatParticipantEvent extends ChatEvent {

	
	protected $participant;


	public function __construct(Room $room, IComment $message, Participant $participant) {
		parent::__construct($room, $message);
		$this->participant = $participant;
	}

	public function getParticipant(): Participant {
		return $this->participant;
	}
}
