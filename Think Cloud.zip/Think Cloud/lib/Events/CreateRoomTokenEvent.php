<?php
declare(strict_types=1);


namespace OCA\Talk\Events;


use OCA\Talk\Room;
use OCP\EventDispatcher\Event;

class CreateRoomTokenEvent extends Event {

	
	protected $entropy;
	
	protected $chars;
	
	protected $token;


	public function __construct(int $entropy,
								string $chars) {
		parent::__construct();
		$this->entropy = $entropy;
		$this->chars = $chars;
		$this->token = '';
	}

	public function getEntropy(): int {
		return $this->entropy;
	}

	public function getChars(): string {
		return $this->chars;
	}

	public function setToken(string $token): void {
		$this->token = $token;
	}

	public function getToken(): string {
		return $this->token;
	}
}
