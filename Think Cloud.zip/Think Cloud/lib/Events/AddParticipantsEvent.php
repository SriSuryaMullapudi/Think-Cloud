<?php
declare(strict_types=1);
namespace OCA\Talk\Events;


use OCA\Talk\Room;

class AddParticipantsEvent extends RoomEvent {

	
	protected $participants;


	public function __construct(Room $room,
								array $participants) {
		parent::__construct($room);
		$this->participants = $participants;
	}

		public function getParticipants(): array {
		return $this->participants;
	}
}
