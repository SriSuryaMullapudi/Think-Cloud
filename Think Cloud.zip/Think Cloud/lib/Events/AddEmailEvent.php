<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Room;

class AddEmailEvent extends RoomEvent {

	/** @var string */
	protected $email;


	public function __construct(Room $room,
								string $email) {
		parent::__construct($room);
		$this->email = $email;
	}

	
	public function getEmail(): string {
		return $this->email;
	}
}
