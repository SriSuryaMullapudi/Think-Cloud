<?php
declare(strict_types=1);


namespace OCA\Talk\Events;


use OCA\Talk\Room;
use OCP\Comments\IComment;

class ChatEvent extends RoomEvent {

	
	protected $comment;


	public function __construct(Room $room, IComment $comment) {
		parent::__construct($room);
		$this->comment = $comment;
	}

	public function getComment(): IComment {
		return $this->comment;
	}
}
