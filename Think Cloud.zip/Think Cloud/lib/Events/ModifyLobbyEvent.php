<?php
declare(strict_types=1);

namespace OCA\Talk\Events;


use OCA\Talk\Room;
use OCP\EventDispatcher\Event;

class ModifyLobbyEvent extends ModifyRoomEvent {

	
	protected $lobbyTimer;
	
	protected $timerReached;

	public function __construct(Room $room,
								string $parameter,
								int $newValue,
								int $oldValue,
								?\DateTime $lobbyTimer,
								bool $timerReached) {
		parent::__construct($room, $parameter, $newValue, $oldValue);
		$this->lobbyTimer = $lobbyTimer;
		$this->timerReached = $timerReached;
	}

	
	public function getLobbyTimer(): ?\DateTime {
		return $this->lobbyTimer;
	}

	
	public function isTimerReached(): bool {
		return $this->timerReached;
	}
}
