<?php
declare(strict_types=1);


namespace OCA\Talk\Controller;

use Doctrine\DBAL\DBALException;
use OCA\Talk\GuestManager;
use OCA\Talk\Participant;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\DataResponse;
use OCP\IRequest;

class GuestController extends AEnvironmentAwareController {

	
	private $guestManager;

	public function __construct(string $appName,
								IRequest $request,
								GuestManager $guestManager) {
		parent::__construct($appName, $request);

		$this->guestManager = $guestManager;
	}

	
	public function setDisplayName(string $displayName): DataResponse {
		$participant = $this->getParticipant();
		if (!$participant instanceof Participant) {
			return new DataResponse([], Http::STATUS_NOT_FOUND);
		}

		if (!$participant->isGuest()) {
			return new DataResponse([], Http::STATUS_FORBIDDEN);
		}

		try {
			$this->guestManager->updateName($this->getRoom(), $participant, $displayName);
		} catch (DBALException $e) {
			return new DataResponse([], Http::STATUS_INTERNAL_SERVER_ERROR);
		}

		return new DataResponse();
	}

}
