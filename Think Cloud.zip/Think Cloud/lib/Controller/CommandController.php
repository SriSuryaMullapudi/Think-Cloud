<?php
namespace OCA\Talk\Controller;

use OCA\Talk\Model\Command;
use OCA\Talk\Service\CommandService;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\OCSController;
use OCP\IRequest;

class CommandController extends OCSController {

	/** @var CommandService */
	protected $commandService;

	/**
	 * @param string $appName
	 * @param IRequest $request
	 * @param CommandService $commandService
	 */
	public function __construct($appName,
								IRequest $request,
								CommandService $commandService) {
		parent::__construct($appName, $request);
		$this->commandService = $commandService;
	}

	
	public function index(): DataResponse {
		$commands = $this->commandService->findAll();

		$result = array_map(function(Command $command) {
			return $command->asArray();
		}, $commands);

		return new DataResponse($result);
	}
}
