<?php
declare(strict_types=1);


namespace OCA\Talk\Controller;

use OCA\Talk\Manager;
use OCA\Talk\Participant;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\OCSController;
use OCP\IRequest;
use OCP\IUser;
use OCP\IUserManager;
use OCP\IUserSession;
use OCP\Share\IManager as IShareManager;
use OCP\Share\Exceptions\ShareNotFound;
use OCP\Share\IShare;

class PublicShareAuthController extends OCSController {

	
	private $userManager;
	
	private $shareManager;
	
	private $userSession;
		private $manager;

	public function __construct(
			string $appName,
			IRequest $request,
			IUserManager $userManager,
			IShareManager $shareManager,
			IUserSession $userSession,
			Manager $manager
	) {
		parent::__construct($appName, $request);
		$this->userManager = $userManager;
		$this->shareManager = $shareManager;
		$this->userSession = $userSession;
		$this->manager = $manager;
	}

	
	public function createRoom(string $shareToken): DataResponse {
		try {
			$share = $this->shareManager->getShareByToken($shareToken);
		} catch (ShareNotFound $e) {
			return new DataResponse([], Http::STATUS_NOT_FOUND);
		}

		if (!$share->getSendPasswordByTalk()) {
			return new DataResponse([], Http::STATUS_NOT_FOUND);
		}

		$sharerUser = $this->userManager->get($share->getSharedBy());

		if (!$sharerUser instanceof IUser) {
			return new DataResponse([], Http::STATUS_NOT_FOUND);
		}

		if ($share->getShareType() === IShare::TYPE_EMAIL) {
			$roomName = $share->getSharedWith();
		} else {
			$roomName = trim($share->getTarget(), '/');
		}

		
		$room = $this->manager->createPublicRoom($roomName, 'share:password', $shareToken);
		$room->addUsers([
			'userId' => $sharerUser->getUID(),
			'participantType' => Participant::OWNER,
		]);

		$user = $this->userSession->getUser();
		$userId = $user instanceof IUser ? $user->getUID() : '';

		return new DataResponse([
			'token' => $room->getToken(),
			'name' => $room->getName(),
			'displayName' => $room->getDisplayName($userId),
		], Http::STATUS_CREATED);
	}
}
