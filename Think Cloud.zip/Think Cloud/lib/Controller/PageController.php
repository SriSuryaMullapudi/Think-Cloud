<?php
declare(strict_types=1);


namespace OCA\Talk\Controller;

use OC\HintException;
use OCA\Talk\Exceptions\ParticipantNotFoundException;
use OCA\Talk\Exceptions\RoomNotFoundException;
use OCA\Talk\Config;
use OCA\Talk\Manager;
use OCA\Talk\Participant;
use OCA\Talk\Room;
use OCA\Talk\TalkSession;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\ContentSecurityPolicy;
use OCP\AppFramework\Http\RedirectResponse;
use OCP\AppFramework\Http\Response;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\Template\PublicTemplateResponse;
use OCP\ILogger;
use OCP\IRequest;
use OCP\IURLGenerator;
use OCP\IUser;
use OCP\IUserSession;
use OCP\Notification\IManager;

class PageController extends Controller {
	
	private $userId;
	
	private $api;
	
	private $talkSession;
	
	private $userSession;
	
	private $logger;
	
	private $manager;
	
	private $url;
		private $notificationManager;
	
	private $config;

	public function __construct(string $appName,
								IRequest $request,
								RoomController $api,
								TalkSession $session,
								IUserSession $userSession,
								?string $UserId,
								ILogger $logger,
								Manager $manager,
								IURLGenerator $url,
								IManager $notificationManager,
								Config $config) {
		parent::__construct($appName, $request);
		$this->api = $api;
		$this->talkSession = $session;
		$this->userSession = $userSession;
		$this->userId = $UserId;
		$this->logger = $logger;
		$this->manager = $manager;
		$this->url = $url;
		$this->notificationManager = $notificationManager;
		$this->config = $config;
	}

		public function showCall(string $token): Response {
		
		return $this->index($token);
	}

	
	public function authenticatePassword(string $token, string $password = ''): Response {
				return $this->index($token, '', $password);
	}

	
	public function index(string $token = '', string $callUser = '', string $password = ''): Response {
		$user = $this->userSession->getUser();
		if (!$user instanceof IUser) {
			return $this->guestEnterRoom($token, $password);
		}

		if ($token !== '') {
			$room = null;
			try {
				$room = $this->manager->getRoomByToken($token);
				$notification = $this->notificationManager->createNotification();
				try {
					$notification->setApp('spreed')
						->setUser($this->userId)
						->setObject('room', $room->getToken());
					$this->notificationManager->markProcessed($notification);
					$notification->setObject('call', $room->getToken());
					$this->notificationManager->markProcessed($notification);
				} catch (\InvalidArgumentException $e) {
					$this->logger->logException($e, ['app' => 'spreed']);
				}

								if ($room->getType() !== Room::PUBLIC_CALL) {
					$this->manager->getRoomForParticipant($room->getId(), $this->userId);
				}
			} catch (RoomNotFoundException $e) {
								$token = '';
			}

			if ($room instanceof Room && $room->hasPassword()) {
								try {
					$participant = $room->getParticipant($this->userId);
					$requirePassword = $participant->getParticipantType() === Participant::USER_SELF_JOINED;
				} catch (ParticipantNotFoundException $e) {
					$requirePassword = true;
				}

				if ($requirePassword) {
					$password = $password !== '' ? $password : (string) $this->talkSession->getPasswordForRoom($token);

					$passwordVerification = $room->verifyPassword($password);

					if ($passwordVerification['result']) {
						$this->talkSession->setPasswordForRoom($token, $password);
					} else {
						$this->talkSession->removePasswordForRoom($token);
						if ($passwordVerification['url'] === '') {
							return new TemplateResponse($this->appName, 'authenticate', [
								'wrongpw' => $password !== '',
							], 'guest');
						}

						return new RedirectResponse($passwordVerification['url']);
					}
				}
			}
		} else {
			$response = $this->api->createRoom(Room::ONE_TO_ONE_CALL, $callUser);
			if ($response->getStatus() !== Http::STATUS_NOT_FOUND) {
				$data = $response->getData();
				return $this->redirectToConversation($data['token']);
			}
		}

		$params = [
			'token' => $token,
			'signaling-settings' => $this->config->getSettings($this->userId),
		];
		$response = new TemplateResponse($this->appName, 'index', $params);
		$csp = new ContentSecurityPolicy();
		$csp->addAllowedConnectDomain('*');
		$csp->addAllowedMediaDomain('blob:');
		$response->setContentSecurityPolicy($csp);
		return $response;
	}

	
	protected function guestEnterRoom(string $token, string $password): Response {
		try {
			$room = $this->manager->getRoomByToken($token);
			if ($room->getType() !== Room::PUBLIC_CALL) {
				throw new RoomNotFoundException();
			}
		} catch (RoomNotFoundException $e) {
			return new RedirectResponse($this->url->linkToRoute('core.login.showLoginForm', [
				'redirect_url' => $this->url->linkToRoute('spreed.Page.index', ['token' => $token]),
			]));
		}

		if ($room->hasPassword()) {
			$password = $password !== '' ? $password : (string) $this->talkSession->getPasswordForRoom($token);

			$passwordVerification = $room->verifyPassword($password);
			if ($passwordVerification['result']) {
				$this->talkSession->setPasswordForRoom($token, $password);
			} else {
				$this->talkSession->removePasswordForRoom($token);
				if ($passwordVerification['url'] === '') {
					return new TemplateResponse($this->appName, 'authenticate', [
						'wrongpw' => $password !== '',
					], 'guest');
				}

				return new RedirectResponse($passwordVerification['url']);
			}
		}

		$params = [
			'token' => $token,
			'signaling-settings' => $this->config->getSettings($this->userId),
		];
		$response = new PublicTemplateResponse($this->appName, 'index', $params);
		$response->setFooterVisible(false);
		$csp = new ContentSecurityPolicy();
		$csp->addAllowedConnectDomain('*');
		$csp->addAllowedMediaDomain('blob:');
		$response->setContentSecurityPolicy($csp);
		return $response;
	}

	
	protected function redirectToConversation(string $token): RedirectResponse {
		// These redirects are already done outside of this method
		if ($this->userId === null) {
			try {
				$room = $this->manager->getRoomByToken($token);
				if ($room->getType() !== Room::PUBLIC_CALL) {
					throw new RoomNotFoundException();
				}
				return new RedirectResponse($this->url->linkToRoute('spreed.Page.index', ['token' => $token]));
			} catch (RoomNotFoundException $e) {
				return new RedirectResponse($this->url->linkToRoute('core.login.showLoginForm', [
					'redirect_url' => $this->url->linkToRoute('spreed.Page.index', ['token' => $token]),
				]));
			}
		}
		return new RedirectResponse($this->url->linkToRoute('spreed.Page.index', ['token' => $token]));
	}
}
