<?php
declare(strict_types=1);

namespace OCA\Talk\Controller;

use OCA\Talk\Participant;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Utility\ITimeFactory;
use OCP\IRequest;

class CallController extends AEnvironmentAwareController {

	
	private $timeFactory;

	public function __construct(string $appName,
								IRequest $request,
								ITimeFactory $timeFactory) {
		parent::__construct($appName, $request);
		$this->timeFactory = $timeFactory;
	}

	
	public function getPeersForCall(): DataResponse {
		$result = [];
		$participants = $this->room->getParticipants($this->timeFactory->getTime() - 30);
		foreach ($participants as $participant) {
			if ($participant->getSessionId() === '0' || $participant->getInCallFlags() === Participant::FLAG_DISCONNECTED) {
				// User is not active in call
				continue;
			}

			$result[] = [
				'userId' => $participant->getUser(),
				'token' => $this->room->getToken(),
				'lastPing' => $participant->getLastPing(),
				'sessionId' => $participant->getSessionId(),
			];
		}

		return new DataResponse($result);
	}

	
	public function joinCall(?int $flags): DataResponse {
		$this->room->ensureOneToOneRoomIsFilled();

		$sessionId = $this->participant->getSessionId();
		if ($sessionId === '0') {
			return new DataResponse([], Http::STATUS_NOT_FOUND);
		}

		if ($flags === null) {
			// Default flags: user is in room with audio/video.
			$flags = Participant::FLAG_IN_CALL | Participant::FLAG_WITH_AUDIO | Participant::FLAG_WITH_VIDEO;
		}

		$this->room->changeInCall($this->participant, $flags);

		return new DataResponse();
	}

	
	public function leaveCall(): DataResponse {
		$sessionId = $this->participant->getSessionId();
		if ($sessionId === '0') {
			return new DataResponse([], Http::STATUS_NOT_FOUND);
		}

		$this->room->changeInCall($this->participant, Participant::FLAG_DISCONNECTED);

		return new DataResponse();
	}

}
