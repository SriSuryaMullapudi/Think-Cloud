<?php
declare(strict_types=1);

namespace OCA\Talk\Settings;


use OCP\AppFramework\Http\TemplateResponse;
use OCP\IConfig;
use OCP\Settings\ISettings;

class Personal implements ISettings {

		private $config;

	public function __construct(IConfig $config) {
		$this->config = $config;
	}

	
	public function getForm(): TemplateResponse {
		$parameters = [ 'clients' => $this->getClientLinks() ];
		return new TemplateResponse('spreed', 'settings/personal/clients', $parameters);
	}

	
	public function getSection(): string {
		return 'sync-clients';
	}

	
	public function getPriority(): int {
		return 30;
	}

	
	private function getClientLinks(): array {
		$clients = [
			'android' => $this->config->getSystemValue('talk_customclient_android', 'https://play.google.com/store/apps/details?id=com.nextcloud.talk2'),
			'ios' => $this->config->getSystemValue('talk_customclient_ios', 'https://geo.itunes.apple.com/us/app/nextcloud-talk/id1296825574')
		];
		return $clients;
	}
}
