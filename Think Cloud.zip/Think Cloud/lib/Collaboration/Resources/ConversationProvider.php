<?php
declare(strict_types=1);

namespace OCA\Talk\Collaboration\Resources;

use OCA\Talk\Exceptions\ParticipantNotFoundException;
use OCA\Talk\Exceptions\RoomNotFoundException;
use OCA\Talk\Manager;
use OCA\Talk\Participant;
use OCA\Talk\Room;
use OCP\Collaboration\Resources\IProvider;
use OCP\Collaboration\Resources\IResource;
use OCP\Collaboration\Resources\ResourceException;
use OCP\IURLGenerator;
use OCP\IUser;
use OCP\IUserSession;

class ConversationProvider implements IProvider {

	/** @var Manager */
	protected $manager;
	/** @var IUserSession */
	protected $userSession;
	/** @var IURLGenerator */
	protected $urlGenerator;

	public function __construct(Manager $manager,
								IUserSession $userSession,
								IURLGenerator $urlGenerator) {
		$this->manager = $manager;
		$this->userSession = $userSession;
		$this->urlGenerator = $urlGenerator;
	}

	public function getResourceRichObject(IResource $resource): array {
		try {
			$room = $this->manager->getRoomByToken($resource->getId());
			$user = $this->userSession->getUser();

			$iconURL = $this->urlGenerator->getAbsoluteURL($this->urlGenerator->imagePath('spreed', 'app-dark.svg'));
			

			return [
				'type' => 'room',
				'id' => $resource->getId(),
				'name' => $room->getDisplayName($user instanceof IUser ? $user->getUID() : ''),
				'call-type' => $this->getRoomType($room),
				'iconUrl' => $iconURL,
				'link' => $this->urlGenerator->linkToRouteAbsolute('spreed.pagecontroller.showCall', ['token' => $room->getToken()])
			];
		} catch (RoomNotFoundException $e) {
			throw new ResourceException('Conversation not found');
		}
	}

	public function canAccessResource(IResource $resource, IUser $user = null): bool {
		$userId = $user instanceof IUser ? $user->getUID() : null;
		if ($userId === null) {
			throw new ResourceException('Guests are not supported at the moment');
		}

		try {
			$room = $this->manager->getRoomForParticipantByToken(
				$resource->getId(),
				$userId
			);

			
			$participant = $room->getParticipant($userId);
			return $participant->getParticipantType() !== Participant::USER_SELF_JOINED;
		} catch (RoomNotFoundException $e) {
			throw new ResourceException('Conversation not found');
		} catch (ParticipantNotFoundException $e) {
			throw new ResourceException('Participant not found');
		}
	}

	public function getType(): string {
		return 'room';
	}

	
	protected function getRoomType(Room $room): string {
		switch ($room->getType()) {
			case Room::ONE_TO_ONE_CALL:
				return 'one2one';
			case Room::GROUP_CALL:
				return 'group';
			case Room::PUBLIC_CALL:
				return 'public';
			default:
				throw new \InvalidArgumentException('Unknown room type');
		}
	}
}
