<?php
declare(strict_types=1);


namespace OCA\Talk\Collaboration\Collaborators;

use OCA\Talk\Manager;
use OCA\Talk\Room;
use OCP\Collaboration\Collaborators\ISearchPlugin;
use OCP\Collaboration\Collaborators\ISearchResult;
use OCP\Collaboration\Collaborators\SearchResultType;
use OCP\IUserSession;
use OCP\Share\IShare;

class RoomPlugin implements ISearchPlugin {

	/** @var Manager */
	private $manager;

	/** @var IUserSession */
	private $userSession;

	public function __construct(Manager $manager,
								IUserSession $userSession) {
		$this->manager = $manager;
		$this->userSession = $userSession;
	}

		public function search($search, $limit, $offset, ISearchResult $searchResult): bool {
		if (empty($search)) {
			return false;
		}

		$userId = $this->userSession->getUser()->getUID();

		$result = ['wide' => [], 'exact' => []];

		$rooms = $this->manager->getRoomsForParticipant($userId);
		foreach ($rooms as $room) {
			if ($room->getReadOnly() === Room::READ_ONLY) {
				
				continue;
			}

			if (stripos($room->getDisplayName($userId), $search) !== false) {
				$item = $this->roomToSearchResultItem($room, $userId);

				if (strtolower($item['label']) === strtolower($search)) {
					$result['exact'][] = $item;
				} else {
					$result['wide'][] = $item;
				}
			}
		}

		$type = new SearchResultType('rooms');
		$searchResult->addResultSet($type, $result['wide'], $result['exact']);

		return false;
	}

	private function roomToSearchResultItem(Room $room, string $userId): array {
		return
		[
			'label' => $room->getDisplayName($userId),
			'value' => [
				'shareType' => IShare::TYPE_ROOM,
				'shareWith' => $room->getToken()
			]
		];
	}

}
