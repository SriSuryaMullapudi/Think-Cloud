<?php
declare(strict_types=1);

namespace OCA\Talk\Files;

use OCA\GroupFolders\Mount\GroupFolderStorage;
use OCP\Files\FileInfo;
use OCP\Files\IRootFolder;
use OCP\Files\Node;
use OCP\Files\NotFoundException;
use OCP\ISession;
use OCP\Share\Exceptions\ShareNotFound;
use OCP\Share\IManager as IShareManager;
use OCP\Share\IShare;

class Util {

	
	private $rootFolder;
	
	private $session;
	
	private $shareManager;
		private $accessLists = [];

	public function __construct(IRootFolder $rootFolder,
			ISession $session,
			IShareManager $shareManager) {
		$this->rootFolder = $rootFolder;
		$this->session = $session;
		$this->shareManager = $shareManager;
	}

	public function getUsersWithAccessFile(string $fileId): array {
		if (!isset($this->accessLists[$fileId])) {
			$nodes = $this->rootFolder->getById($fileId);

			if (empty($nodes)) {
				return [];
			}

			$node = array_shift($nodes);
			$accessList = $this->shareManager->getAccessList($node);

			$this->accessLists[$fileId] = $accessList['users'];
		}

		return $this->accessLists[$fileId];
	}

	public function canUserAccessFile(string $fileId, string $userId): bool {
		return \in_array($userId, $this->getUsersWithAccessFile($fileId), true);
	}

	public function canGuestAccessFile(string $shareToken): bool {
		try {
			$share = $this->shareManager->getShareByToken($shareToken);
			if ($share->getPassword() !== null) {
				$shareId = $this->session->get('public_link_authenticated');
				if ($share->getId() !== $shareId) {
					throw new ShareNotFound();
				}
			}
			return true;
		} catch (ShareNotFound $e) {
			return false;
		}
	}

	
	public function getAnyPublicShareOfFileOwnedByUserOrAnyDirectShareOfFileAccessibleByUser(string $fileId, string $userId): ?IShare {
		$userFolder = $this->rootFolder->getUserFolder($userId);
		$nodes = $userFolder->getById($fileId);
		if (empty($nodes)) {
			return null;
		}

		$nodes = array_filter($nodes, function($node) {
			return $node->getType() === FileInfo::TYPE_FILE;
		});

		if (!empty($nodes)) {
			$share = $this->getAnyPublicShareOfNodeOwnedByUser($nodes[0], $userId);
			if ($share) {
				return $share;
			}
		}

		while (!empty($nodes)) {
			$node = array_pop($nodes);

			$share = $this->getAnyDirectShareOfNodeAccessibleByUser($node, $userId);
			if ($share) {
				return $share;
			}

			try {
				$nodes[] = $node->getParent();
			} catch (NotFoundException $e) {
			}
		}

		return null;
	}

	
	private function getAnyPublicShareOfNodeOwnedByUser(Node $node, string $userId): ?IShare {
		$reshares = false;
		$limit = 1;

		$shares = $this->shareManager->getSharesBy($userId, IShare::TYPE_LINK, $node, $reshares, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		$shares = $this->shareManager->getSharesBy($userId, IShare::TYPE_EMAIL, $node, $reshares, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		return null;
	}

	private function getAnyDirectShareOfNodeAccessibleByUser(Node $node, string $userId): ?IShare {
		$reshares = false;
		$limit = 1;

		$shares = $this->shareManager->getSharesBy($userId, IShare::TYPE_USER, $node, $reshares, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		$shares = $this->shareManager->getSharesBy($userId, IShare::TYPE_GROUP, $node, $reshares, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		$shares = $this->shareManager->getSharesBy($userId, IShare::TYPE_CIRCLE, $node, $reshares, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		$shares = $this->shareManager->getSharesBy($userId, IShare::TYPE_ROOM, $node, $reshares, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		if (!$node->isShared()) {
			return null;
		}

		$shares = $this->shareManager->getSharedWith($userId, IShare::TYPE_USER, $node, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		$shares = $this->shareManager->getSharedWith($userId, IShare::TYPE_GROUP, $node, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		$shares = $this->shareManager->getSharedWith($userId, IShare::TYPE_CIRCLE, $node, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		$shares = $this->shareManager->getSharedWith($userId, IShare::TYPE_ROOM, $node, $limit);
		if (!empty($shares)) {
			return $shares[0];
		}

		return null;
	}

	
	public function getGroupFolderNode(string $fileId, string $userId): ?Node {
		$userFolder = $this->rootFolder->getUserFolder($userId);
		$nodes = $userFolder->getById($fileId);
		if (empty($nodes)) {
			return null;
		}

		$nodes = array_filter($nodes, function(Node $node) {
			return $node->getType() === FileInfo::TYPE_FILE;
		});
		if (empty($nodes)) {
			return null;
		}

		
		$node = array_shift($nodes);
		try {
			$storage = $node->getStorage();
			if ($storage->instanceOfStorage(GroupFolderStorage::class)) {
				return $node;
			}
		} catch (NotFoundException $e) {
		}

		return null;
	}

}
