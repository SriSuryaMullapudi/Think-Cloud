<?php
declare(strict_types=1);


namespace OCA\Talk\Files;

use OCA\Talk\Events\JoinRoomGuestEvent;
use OCA\Talk\Events\JoinRoomUserEvent;
use OCA\Talk\Exceptions\ParticipantNotFoundException;
use OCA\Talk\Exceptions\UnauthorizedException;
use OCA\Talk\Room;
use OCA\Talk\TalkSession;
use OCP\EventDispatcher\IEventDispatcher;


class Listener {

	
	protected $util;
	
	protected $talkSession;

	public function __construct(Util $util,
								TalkSession $talkSession) {
		$this->util = $util;
		$this->talkSession = $talkSession;
	}

	public static function register(IEventDispatcher $dispatcher): void {
		$listener = static function(JoinRoomUserEvent $event) {
			/** @var self $listener */
			$listener = \OC::$server->query(self::class);

			try {
				$listener->preventUsersWithoutAccessToTheFileFromJoining($event->getRoom(), $event->getUser()->getUID());
				$listener->addUserAsPersistentParticipant($event->getRoom(), $event->getUser()->getUID());
			} catch (UnauthorizedException $e) {
				$event->setCancelJoin(true);
			}
		};
		$dispatcher->addListener(Room::EVENT_BEFORE_ROOM_CONNECT, $listener);

		$listener = static function(JoinRoomGuestEvent $event) {
			/** @var self $listener */
			$listener = \OC::$server->query(self::class);

			try {
				$listener->preventGuestsFromJoiningIfNotPubliclyAccessible($event->getRoom());
			} catch (UnauthorizedException $e) {
				$event->setCancelJoin( true);
			}
		};
		$dispatcher->addListener(Room::EVENT_BEFORE_GUEST_CONNECT, $listener);
	}

	
	public function preventUsersWithoutAccessToTheFileFromJoining(Room $room, string $userId): void {
		if ($room->getObjectType() !== 'file') {
			return;
		}

		
		$shareToken = $this->talkSession->getFileShareTokenForRoom($room->getToken());
		if ($shareToken && $this->util->canGuestAccessFile($shareToken)) {
			return;
		}

		$share = $this->util->getAnyPublicShareOfFileOwnedByUserOrAnyDirectShareOfFileAccessibleByUser($room->getObjectId(), $userId);
		if (!$share) {
			$groupFolder = $this->util->getGroupFolderNode($room->getObjectId(), $userId);
			if (!$groupFolder) {
				throw new UnauthorizedException('User does not have access to the file');
			}
		}
	}

	
	public function addUserAsPersistentParticipant(Room $room, string $userId): void {
		if ($room->getObjectType() !== 'file') {
			return;
		}

		if (!$this->util->getAnyPublicShareOfFileOwnedByUserOrAnyDirectShareOfFileAccessibleByUser($room->getObjectId(), $userId)) {
			return;
		}

		try {
			$room->getParticipant($userId);
		} catch (ParticipantNotFoundException $e) {
			$room->addUsers(['userId' => $userId]);
		}
	}

	
	protected function preventGuestsFromJoiningIfNotPubliclyAccessible(Room $room): void {
		if ($room->getObjectType() !== 'file') {
			return;
		}

		$shareToken = $this->talkSession->getFileShareTokenForRoom($room->getToken());
		if ($shareToken && $this->util->canGuestAccessFile($shareToken)) {
			return;
		}

		throw new UnauthorizedException('Guests are not allowed in this room');
	}

}
