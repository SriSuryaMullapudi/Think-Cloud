<?php
declare(strict_types=1);


namespace OCA\Talk\Files;

use OCA\Files\Event\LoadSidebar;
use OCA\Talk\AppInfo\Application;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventDispatcher;
use OCP\EventDispatcher\IEventListener;
use OCP\Util;


class TemplateLoader implements IEventListener {

	public static function register(IEventDispatcher $dispatcher): void {
		$dispatcher->addServiceListener(LoadSidebar::class, TemplateLoader::class);
	}

	
	public function handle(Event $event): void {
		if (!($event instanceof LoadSidebar)) {
			return;
		}

		$config = \OC::$server->getConfig();
		if ($config->getAppValue('spreed', 'conversations_files', '1') !== '1') {
			return;
		}

		Util::addStyle(Application::APP_ID, 'merged-files');
		Util::addScript(Application::APP_ID, 'files-sidebar-tab');
		Util::addScript(Application::APP_ID, 'talk-chat-tab');
	}

}
