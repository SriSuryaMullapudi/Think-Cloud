<?php
declare(strict_types=1);

namespace OCA\Talk;

use OCA\Talk\Chat\ChatManager;
use OCP\Capabilities\IPublicCapability;
use OCP\IConfig;
use OCP\IUser;
use OCP\IUserSession;

class Capabilities implements IPublicCapability {

	/** @var IConfig */
	protected $serverConfig;
	/** @var Config */
	protected $talkConfig;
	/** @var IUserSession */
	protected $userSession;

	public function __construct(IConfig $serverConfig,
								Config $talkConfig,
								IUserSession $userSession) {
		$this->serverConfig = $serverConfig;
		$this->talkConfig = $talkConfig;
		$this->userSession = $userSession;
	}

	public function getCapabilities(): array {
		$user = $this->userSession->getUser();
		if ($user instanceof IUser && $this->talkConfig->isDisabledForUser($user)) {
			return [];
		}

		$maxChatLength = 1000;
		if (version_compare($this->serverConfig->getSystemValueString('version', '0.0.0'), '16.0.2', '>=')) {
			$maxChatLength = ChatManager::MAX_CHAT_LENGTH;
		}

		return [
			'spreed' => [
				'features' => [
					'audio',
					'video',
					'chat-v2',
					'guest-signaling',
					'empty-group-room',
					'guest-display-names',
					'multi-room-users',
					'favorites',
					'last-room-activity',
					'no-ping',
					'system-messages',
					'mention-flag',
					'in-call-flags',
					'notification-levels',
					'invite-groups-and-mails',
					'locked-one-to-one-rooms',
					'read-only-rooms',
					'chat-read-marker',
					'webinary-lobby',
					'start-call-flag',
					'chat-replies',
					'circles-support',
				],
				'config' => [
					'chat' => [
						'max-length' => $maxChatLength,
					],
				],
			],
		];
	}
}
