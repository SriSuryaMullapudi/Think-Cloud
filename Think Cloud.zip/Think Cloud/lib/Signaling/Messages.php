<?php
declare(strict_types=1);
namespace OCA\Talk\Signaling;


use OCA\Talk\Room;
use OCP\AppFramework\Utility\ITimeFactory;
use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IDBConnection;

class Messages {

	/** @var IDBConnection */
	protected $db;

	/** @var ITimeFactory */
	protected $timeFactory;

	public function __construct(IDBConnection $db,
								ITimeFactory $timeFactory) {
		$this->db = $db;
		$this->timeFactory = $timeFactory;
	}

	
	public function deleteMessages(array $sessionIds): void {
		$query = $this->db->getQueryBuilder();
		$query->delete('talk_signaling')
			->where($query->expr()->in('recipient', $query->createNamedParameter($sessionIds, IQueryBuilder::PARAM_STR_ARRAY)))
			->orWhere($query->expr()->in('sender', $query->createNamedParameter($sessionIds, IQueryBuilder::PARAM_STR_ARRAY)));
		$query->execute();
	}

	
	public function addMessage(string $senderSessionId, string $recipientSessionId, string $message): void {
		$query = $this->db->getQueryBuilder();
		$query->insert('talk_signaling')
			->values(
				[
					'sender' => $query->createNamedParameter($senderSessionId),
					'recipient' => $query->createNamedParameter($recipientSessionId),
					'timestamp' => $query->createNamedParameter($this->timeFactory->getTime()),
					'message' => $query->createNamedParameter($message),
				]
			);
		$query->execute();
	}

	
	public function addMessageForAllParticipants(Room $room, string $message): void {
		$query = $this->db->getQueryBuilder();
		$query->insert('talk_signaling')
			->values(
				[
					'sender' => $query->createParameter('sender'),
					'recipient' => $query->createParameter('recipient'),
					'timestamp' => $query->createNamedParameter($this->timeFactory->getTime()),
					'message' => $query->createNamedParameter($message),
				]
			);

		foreach ($room->getActiveSessions() as $sessionId) {
			$query->setParameter('sender', $sessionId)
				->setParameter('recipient', $sessionId)
				->execute();
		}
	}

	
	public function getAndDeleteMessages(string $sessionId): array {
		$messages = [];
		$time = $this->timeFactory->getTime() - 1;

		$query = $this->db->getQueryBuilder();
		$query->select('*')
			->from('talk_signaling')
			->where($query->expr()->eq('recipient', $query->createNamedParameter($sessionId)))
			->andWhere($query->expr()->lte('timestamp', $query->createNamedParameter($time)));
		$result = $query->execute();

		while ($row = $result->fetch()) {
			$messages[] = ['type' => 'message', 'data' => $row['message']];
		}
		$result->closeCursor();

		$query = $this->db->getQueryBuilder();
		$query->delete('talk_signaling')
			->where($query->expr()->eq('recipient', $query->createNamedParameter($sessionId)))
			->andWhere($query->expr()->lte('timestamp', $query->createNamedParameter($time)));
		$query->execute();

		return $messages;
	}

	
	public function expireOlderThan(int $olderThan): void {
		$time = $this->timeFactory->getTime() - $olderThan;

		$query = $this->db->getQueryBuilder();
		$query->delete('talk_signaling')
			->where($query->expr()->lt('timestamp', $query->createNamedParameter($time)));
		$query->execute();
	}
}
