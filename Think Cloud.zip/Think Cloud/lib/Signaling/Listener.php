<?php
declare(strict_types=1);

namespace OCA\Talk\Signaling;

use OCA\Talk\Chat\ChatManager;
use OCA\Talk\Config;
use OCA\Talk\Events\AddParticipantsEvent;
use OCA\Talk\Events\ChatEvent;
use OCA\Talk\Events\ChatParticipantEvent;
use OCA\Talk\Events\ModifyLobbyEvent;
use OCA\Talk\Events\ModifyParticipantEvent;
use OCA\Talk\Events\ModifyRoomEvent;
use OCA\Talk\Events\ParticipantEvent;
use OCA\Talk\Events\RemoveParticipantEvent;
use OCA\Talk\Events\RemoveUserEvent;
use OCA\Talk\Events\RoomEvent;
use OCA\Talk\GuestManager;
use OCA\Talk\Participant;
use OCA\Talk\Room;
use OCP\EventDispatcher\IEventDispatcher;

class Listener {

	public static function register(IEventDispatcher $dispatcher): void {
		self::registerInternalSignaling($dispatcher);
		self::registerExternalSignaling($dispatcher);
	}

	protected static function isUsingInternalSignaling(): bool {
		
		$config = \OC::$server->query(Config::class);
		return empty($config->getSignalingServers());
	}

	protected static function registerInternalSignaling(IEventDispatcher $dispatcher): void {
		$listener = static function(RoomEvent $event) {
			if (!self::isUsingInternalSignaling()) {
				return;
			}

			
			$messages = \OC::$server->query(Messages::class);
			$messages->addMessageForAllParticipants($event->getRoom(), 'refresh-participant-list');
		};
		$dispatcher->addListener(Room::EVENT_AFTER_ROOM_CONNECT, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_GUEST_CONNECT, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_SESSION_JOIN_CALL, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_SESSION_LEAVE_CALL, $listener);
		$dispatcher->addListener(GuestManager::EVENT_AFTER_NAME_UPDATE, $listener);

		$listener = static function(ParticipantEvent $event) {
			if (!self::isUsingInternalSignaling()) {
				return;
			}

			$room = $event->getRoom();

			
			$messages = \OC::$server->query(Messages::class);
			$messages->addMessageForAllParticipants($room, 'refresh-participant-list');

			
			$participant = $event->getParticipant();
			if ($participant->getSessionId() !== '0') {
				$messages->addMessage($participant->getSessionId(), $participant->getSessionId(), 'refresh-participant-list');
			}
		};
		$dispatcher->addListener(Room::EVENT_AFTER_USER_REMOVE, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_PARTICIPANT_REMOVE, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_ROOM_DISCONNECT, $listener);

		$listener = static function(RoomEvent $event) {
			$room = $event->getRoom();
			if (!self::isUsingInternalSignaling()) {
				return;
			}

			
			$messages = \OC::$server->query(Messages::class);
			$participants = $room->getParticipantsLegacy();
			foreach ($participants['users'] as $participant) {
				$messages->addMessage($participant['sessionId'], $participant['sessionId'], 'refresh-participant-list');
			}
			foreach ($participants['guests'] as $participant) {
				$messages->addMessage($participant['sessionId'], $participant['sessionId'], 'refresh-participant-list');
			}
		};
		$dispatcher->addListener(Room::EVENT_BEFORE_ROOM_DELETE, $listener);
	}

	protected static function registerExternalSignaling(IEventDispatcher $dispatcher): void {
		$dispatcher->addListener(Room::EVENT_AFTER_USERS_ADD, static function(AddParticipantsEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$notifier->roomInvited($event->getRoom(), $event->getParticipants());
		});
		$listener = static function(RoomEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$notifier->roomModified($event->getRoom());
		};
		$dispatcher->addListener(Room::EVENT_AFTER_NAME_SET, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_PASSWORD_SET, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_TYPE_SET, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_READONLY_SET, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_LOBBY_STATE_SET, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_PARTICIPANT_TYPE_SET, $listener);
		$dispatcher->addListener(Room::EVENT_BEFORE_ROOM_DELETE, static function(RoomEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$room = $event->getRoom();
			$participants = $room->getParticipantsLegacy();
			$notifier->roomDeleted($room, $participants);
		});
		$dispatcher->addListener(Room::EVENT_AFTER_USER_REMOVE, static function(RemoveUserEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$notifier->roomsDisinvited($event->getRoom(), [$event->getUser()->getUID()]);
		});
		$dispatcher->addListener(Room::EVENT_AFTER_PARTICIPANT_REMOVE, static function(RemoveParticipantEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$notifier->roomSessionsRemoved($event->getRoom(), [$event->getParticipant()->getSessionId()]);
		});

		$listener = static function(ModifyParticipantEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$notifier->roomInCallChanged(
				$event->getRoom(),
				$event->getNewValue(),
				[$event->getParticipant()->getSessionId()]
			);
		};
		$dispatcher->addListener(Room::EVENT_AFTER_SESSION_JOIN_CALL, $listener);
		$dispatcher->addListener(Room::EVENT_AFTER_SESSION_LEAVE_CALL, $listener);

		$dispatcher->addListener(Room::EVENT_AFTER_GUESTS_CLEAN, static function(RoomEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			
			$sessionIds = [];
			$notifier->participantsModified($event->getRoom(), $sessionIds);
		});
		$dispatcher->addListener(GuestManager::EVENT_AFTER_NAME_UPDATE, static function(ModifyParticipantEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$notifier->participantsModified($event->getRoom(), [$event->getParticipant()->getSessionId()]);
		});
		$dispatcher->addListener(ChatManager::EVENT_AFTER_MESSAGE_SEND , static function(ChatParticipantEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$room = $event->getRoom();
			$message = [
				'type' => 'chat',
				'chat' => [
					'refresh' => true,
				],
			];
			$notifier->sendRoomMessage($room, $message);
		});
		$dispatcher->addListener(ChatManager::EVENT_AFTER_SYSTEM_MESSAGE_SEND, static function(ChatEvent $event) {
			if (self::isUsingInternalSignaling()) {
				return;
			}

			
			$notifier = \OC::$server->query(BackendNotifier::class);

			$room = $event->getRoom();
			$message = [
				'type' => 'chat',
				'chat' => [
					'refresh' => true,
				],
			];
			$notifier->sendRoomMessage($room, $message);
		});
	}
}
