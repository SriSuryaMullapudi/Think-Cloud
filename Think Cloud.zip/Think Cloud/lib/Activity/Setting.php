<?php
declare(strict_types=1);
namespace OCA\Talk\Activity;


use OCP\Activity\ISetting;
use OCP\IL10N;

class Setting implements ISetting {

		protected $l;

	public function __construct(IL10N $l) {
		$this->l = $l;
	}

	
	public function getIdentifier(): string {
		return 'spreed';
	}

	
	public function getName(): string {
		return $this->l->t('You were invited to a <strong>conversation</strong> or had a <strong>call</strong>');
	}

	
	public function getPriority(): int {
		return 51;
	}

	
	public function canChangeStream(): bool {
		return true;
	}

	
	public function isDefaultEnabledStream(): bool {
		return true;
	}

	
	public function canChangeMail(): bool {
		return true;
	}

	
	public function isDefaultEnabledMail(): bool {
		return false;
	}
}

