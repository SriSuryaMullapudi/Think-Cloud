<?php
declare(strict_types=1);
namespace OCA\Talk\Activity\Provider;

use OCA\Talk\Exceptions\RoomNotFoundException;
use OCP\Activity\IEvent;

class Invitation extends Base {

	
	public function parse($language, IEvent $event, IEvent $previousEvent = null): IEvent {
		$event = $this->preParse($event);

		if ($event->getSubject() === 'invitation') {
			$l = $this->languageFactory->get('spreed', $language);
			$parameters = $event->getSubjectParameters();

			$roomParameter = $this->getFormerRoom($l, (int) $parameters['room']);
			try {
				$room = $this->manager->getRoomById((int) $parameters['room']);
				$roomParameter = $this->getRoom($room, $event->getAffectedUser());
			} catch (RoomNotFoundException $e) {
			}

			$this->setSubjects($event, $l->t('{actor} invited you to {call}'), [
				'actor' => $this->getUser($parameters['user']),
				'call' => $roomParameter,
			]);
		} else {
			throw new \InvalidArgumentException('Wrong subject');
		}

		return $event;
	}

}
