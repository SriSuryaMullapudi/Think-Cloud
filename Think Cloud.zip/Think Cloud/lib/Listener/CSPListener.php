<?php
declare(strict_types=1);


namespace OCA\Talk\Listener;

use OCA\Talk\Config;
use OCP\AppFramework\Http\ContentSecurityPolicy;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;
use OCP\Security\CSP\AddContentSecurityPolicyEvent;

class CSPListener implements IEventListener {

	
	private $config;

	public function __construct(Config $config) {
		$this->config = $config;
	}

	public function handle(Event $event): void {
		if (!($event instanceof AddContentSecurityPolicyEvent)) {
			return;
		}

		$csp = new ContentSecurityPolicy();
		foreach ($this->config->getAllServerUrlsForCSP() as $server) {
			$csp->addAllowedConnectDomain($server);
		}

		$event->addPolicy($csp);
	}

}
