<?php
declare(strict_types=1);


namespace OCA\Talk\Listener;

use OCP\AppFramework\Http\FeaturePolicy;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;
use OCP\Security\FeaturePolicy\AddFeaturePolicyEvent;

class FeaturePolicyListener implements IEventListener {

	public function handle(Event $event): void {
		if (!($event instanceof AddFeaturePolicyEvent)) {
			return;
		}

		$policy = new FeaturePolicy();
		$policy->addAllowedCameraDomain('\'self\'');
		$policy->addAllowedMicrophoneDomain('\'self\'');
		$event->addPolicy($policy);
	}

}
