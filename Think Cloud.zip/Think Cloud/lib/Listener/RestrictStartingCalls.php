<?php
declare(strict_types=1);


namespace OCA\Talk\Listener;


use OCA\Talk\Events\ModifyParticipantEvent;
use OCA\Talk\Exceptions\ForbiddenException;
use OCA\Talk\Room;
use OCP\EventDispatcher\IEventDispatcher;
use OCP\IConfig;

class RestrictStartingCalls {

		protected $config;

	public function __construct(IConfig $config) {
		$this->config = $config;
	}

	public static function register(IEventDispatcher $dispatcher): void {
		$dispatcher->addListener(Room::EVENT_BEFORE_SESSION_JOIN_CALL, static function(ModifyParticipantEvent $event) {
			/** @var self $listener */
			$listener = \OC::$server->query(self::class);
			$listener->checkStartCallPermissions($event);
		}, 1000);
	}

	
	public function checkStartCallPermissions(ModifyParticipantEvent $event): void {
		$room = $event->getRoom();
		$participant = $event->getParticipant();

		if (!$participant->canStartCall() && !$room->hasSessionsInCall()) {
			throw new ForbiddenException('Can not start a call');
		}
	}
}
