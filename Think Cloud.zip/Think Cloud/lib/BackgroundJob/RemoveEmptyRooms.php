<?php
declare(strict_types=1);

namespace OCA\Talk\BackgroundJob;

use OC\BackgroundJob\TimedJob;
use OCA\Talk\Manager;
use OCA\Talk\Room;
use OCP\ILogger;

/**
 * Class RemoveEmptyRooms
 *
 * @package OCA\Talk\BackgroundJob
 */
class RemoveEmptyRooms extends TimedJob {

	/** @var Manager */
	protected $manager;

	/** @var ILogger */
	protected $logger;

	protected $numDeletedRooms = 0;

	public function __construct(Manager $manager,
								ILogger $logger) {
		// Every 5 minutes
		$this->setInterval(60 * 5);

		$this->manager = $manager;
		$this->logger = $logger;
	}

	protected function run($argument): void {
		$this->manager->forAllRooms([$this, 'callback']);

		if ($this->numDeletedRooms) {
			$this->logger->info('Deleted {numDeletedRooms} rooms because they were empty', [
				'numDeletedRooms' => $this->numDeletedRooms,
				'app' => 'spreed',
			]);
		}
	}

	public function callback(Room $room): void {
		if ($room->getType() === Room::CHANGELOG_CONVERSATION) {
			return;
		}

		if ($room->getNumberOfParticipants(false) === 0 && $room->getObjectType() !== 'file') {
			$room->deleteRoom();
			$this->numDeletedRooms++;
		}
	}
}
