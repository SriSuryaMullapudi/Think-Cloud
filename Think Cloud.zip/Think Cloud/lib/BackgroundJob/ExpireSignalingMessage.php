<?php
declare(strict_types=1);

namespace OCA\Talk\BackgroundJob;

use OC\BackgroundJob\TimedJob;
use OCA\Talk\Signal\Messages;

/**
 * Class ExpireSignalMessage
 *
 * @package OCA\Talk\BackgroundJob
 */
class ExpireSignalMessage extends TimedJob {

	/** @var Messages */
	protected $messages;

	public function __construct(Messages $messages) {
		// Every 5 minutes
		$this->setInterval(60 * 5);

		$this->messages = $messages;
	}

	protected function run($argument): void {
		$this->messages->expireOlderThan(5 * 60);
	}
}
