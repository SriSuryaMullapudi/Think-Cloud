<?php
declare(strict_types=1);

namespace OCA\Talk\Share\Helper;

use OCA\Talk\Exceptions\ParticipantNotFoundException;
use OCA\Talk\Exceptions\RoomNotFoundException;
use OCA\Talk\Manager;
use OCA\Talk\Room;
use OCP\AppFramework\OCS\OCSNotFoundException;
use OCP\AppFramework\Utility\ITimeFactory;
use OCP\IL10N;
use OCP\IUser;
use OCP\IUserManager;
use OCP\Share\IShare;


class ShareAPIController {

	
	private $userId;
	
	private $userManager;
	
	private $manager;
	
	protected $timeFactory;
	
	private $l;

	public function __construct(
			string $UserId,
			IUserManager $userManager,
			Manager $manager,
			ITimeFactory $timeFactory,
			IL10N $l10n
	) {
		$this->userId = $UserId;
		$this->userManager = $userManager;
		$this->manager = $manager;
		$this->timeFactory = $timeFactory;
		$this->l = $l10n;
	}

	
	public function formatShare(IShare $share): array {
		$result = [];

		try {
			$room = $this->manager->getRoomByToken($share->getSharedWith());
		} catch (RoomNotFoundException $e) {
			return $result;
		}

		$result['share_with_displayname'] = $room->getDisplayName($this->userId);
		try {
			$room->getParticipant($this->userId);
		} catch (ParticipantNotFoundException $e) {
			
			$result['share_with'] = 'private_conversation_' . substr(sha1($room->getName() . $room->getId()), 0, 6);
		}
		if ($room->getType() === Room::PUBLIC_CALL) {
			$result['token'] = $share->getToken();
		}

		return $result;
	}

	
	public function createShare(IShare $share, string $shareWith, int $permissions, string $expireDate): void {
		$share->setSharedWith($shareWith);
		$share->setPermissions($permissions);

		if ($expireDate !== '') {
			try {
				$expireDate = $this->parseDate($expireDate);
				$share->setExpirationDate($expireDate);
			} catch (\Exception $e) {
				throw new OCSNotFoundException($this->l->t('Invalid date, date format must be YYYY-MM-DD'));
			}
		}
	}

	
	private function parseDate(string $expireDate): \DateTime {
		try {
			$date = $this->timeFactory->getDateTime($expireDate);
		} catch (\Exception $e) {
			throw new \Exception('Invalid date. Format must be YYYY-MM-DD');
		}

		if ($date === false) {
			throw new \Exception('Invalid date. Format must be YYYY-MM-DD');
		}

		$date->setTime(0, 0, 0);

		return $date;
	}

	
	public function canAccessShare(IShare $share, string $user): bool {
		try {
			$room = $this->manager->getRoomByToken($share->getSharedWith());
		} catch (RoomNotFoundException $e) {
			return false;
		}

		try {
			$room->getParticipant($user);
		} catch (ParticipantNotFoundException $e) {
			return false;
		}

		return true;
	}

}
