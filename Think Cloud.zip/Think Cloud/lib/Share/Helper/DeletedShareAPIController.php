<?php
declare(strict_types=1);


namespace OCA\Talk\Share\Helper;

use OCA\Talk\Exceptions\RoomNotFoundException;
use OCA\Talk\Manager;
use OCA\Talk\Room;
use OCP\IUser;
use OCP\IUserManager;
use OCP\Share\IShare;

class DeletedShareAPIController {

	
	private $userId;
	
	private $manager;

	public function __construct(
			string $UserId,
			Manager $manager
	) {
		$this->userId = $UserId;
		$this->manager = $manager;
	}

	
	public function formatShare(IShare $share): array {
		$result = [];

		try {
			$room = $this->manager->getRoomByToken($share->getSharedWith());
		} catch (RoomNotFoundException $e) {
			return $result;
		}

		$result['share_with_displayname'] = $room->getDisplayName($this->userId);

		return $result;
	}

}
