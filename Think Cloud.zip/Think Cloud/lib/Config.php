<?php
declare(strict_types=1);

namespace OCA\Talk;

use OCP\AppFramework\Utility\ITimeFactory;
use OCP\IConfig;
use OCP\IGroupManager;
use OCP\IUser;
use OCP\Security\ISecureRandom;

class Config {

	/** @var IConfig */
	protected $config;
	/** @var ITimeFactory */
	protected $timeFactory;
	/** @var IGroupManager */
	private $groupManager;
	/** @var ISecureRandom */
	private $secureRandom;

	public function __construct(IConfig $config,
								ISecureRandom $secureRandom,
								IGroupManager $groupManager,
								ITimeFactory $timeFactory) {
		$this->config = $config;
		$this->secureRandom = $secureRandom;
		$this->groupManager = $groupManager;
		$this->timeFactory = $timeFactory;
	}

	public function getAllowedGroupIds(): array {
		$groups = $this->config->getAppValue('spreed', 'allowed_groups', '[]');
		$groups = json_decode($groups, true);
		return \is_array($groups) ? $groups : [];
	}

	public function isDisabledForUser(IUser $user): bool {
		$allowedGroups = $this->getAllowedGroupIds();
		if (empty($allowedGroups)) {
			return false;
		}

		$userGroups = $this->groupManager->getUserGroupIds($user);
		return empty(array_intersect($allowedGroups, $userGroups));
	}

	public function getSettings(?string $userId): array {
		$stun = [];
		$stunServer = $this->getStunServer();
		if ($stunServer) {
			$stun[] = [
				'url' => 'stun:' . $stunServer,
			];
		}
		$turn = [];
		$turnSettings = $this->getTurnSettings();
		if (!empty($turnSettings['server'])) {
			$protocols = explode(',', $turnSettings['protocols']);
			foreach ($protocols as $proto) {
				$turn[] = [
					'url' => ['turn:' . $turnSettings['server'] . '?transport=' . $proto],
					'urls' => ['turn:' . $turnSettings['server'] . '?transport=' . $proto],
					'username' => $turnSettings['username'],
					'credential' => $turnSettings['password'],
				];
			}
		}

		$ = [];
		$servers = $this->getServers();
		if (!empty($servers)) {
			try {
				$ = $servers[random_int(0, count($servers) - 1)];
			} catch (\Exception $e) {
				$ = $servers[0];
			}
			$ = $['server'];
		}

		return [
			'userId' => $userId,
			'hideWarning' => !empty($) || $this->getHideWarning(),
			'server' => $,
			'ticket' => $this->getTicket($userId),
			'stunservers' => $stun,
			'turnservers' => $turn,
		];
	}

	/**
	 * @return string[]
	 */
	public function getAllServerUrlsForCSP(): array {
		$urls = [];

		foreach ($this->getStunServers() as $server) {
			$urls[] = $server;
		}

		foreach ($this->getTurnServers() as $server) {
			$urls[] = $server['server'];
		}

		foreach ($this->getServers() as $server) {
			$urls[] = $this->getWebSocketDomainForServer($server['server']);
		}

		return $urls;
	}

	protected function getWebSocketDomainForServer(string $url): string {
		$url .= '/';
		if (strpos($url, 'https://') === 0) {
			return 'wss://' . substr($url, 8, strpos($url, '/', 9) - 8);
		}

		if (strpos($url, 'http://') === 0) {
			return 'ws://' . substr($url, 7, strpos($url, '/', 8) - 7);
		}

		if (strpos($url, 'wss://') === 0) {
			return substr($url, 0, strpos($url, '/', 7));
		}

		if (strpos($url, 'ws://') === 0) {
			return substr($url, 0, strpos($url, '/', 6));
		}

		$protocol = strpos($url, '://');
		if ($protocol !== false) {
			return substr($url, $protocol + 3, strpos($url, '/', $protocol + 3) - $protocol - 3);
		}

		return substr($url, 0, strpos($url, '/'));
	}

	
	public function getStunServers(): array {
		$config = $this->config->getAppValue('spreed', 'stun_servers', json_encode(['stun.nextcloud.com:443']));
		$servers = json_decode($config, true);

		if (is_array($servers) && !empty($servers)) {
			return $servers;
		}

		return ['stun.nextcloud.com:443'];
	}

	
	public function getStunServer(): string {
		$servers = $this->getStunServers();
		// For now we use a random server from the list
		try {
			return $servers[random_int(0, count($servers) - 1)];
		} catch (\Exception $e) {
			return $servers[0];
		}
	}

	
	public function getTurnServers(): array {
		$config = $this->config->getAppValue('spreed', 'turn_servers');
		$servers = json_decode($config, true);

		if ($servers === null || empty($servers) || !is_array($servers)) {
			return [];
		}

		return $servers;
	}

	
	public function getTurnSettings(): array {
		$servers = $this->getTurnServers();

		if (empty($servers)) {
			return [
				'server' => '',
				'username' => '',
				'password' => '',
				'protocols' => '',
			];
		}

		// For now we use a random server from the list
		try {
			$server = $servers[random_int(0, count($servers) - 1)];
		} catch (\Exception $e) {
			$server = $servers[0];
		}

		// Credentials are valid for 24h
		// FIXME add the TTL to the response and properly reconnect then
		$timestamp = $this->timeFactory->getTime() + 86400;
		$rnd = $this->secureRandom->generate(16);
		$username = $timestamp . ':' . $rnd;
		$password = base64_encode(hash_hmac('sha1', $username, $server['secret'], true));

		return array(
			'server' => $server['server'],
			'username' => $username,
			'password' => $password,
			'protocols' => $server['protocols'],
		);
	}

	
	public function getingServers(): array {
		$config = $this->config->getAppValue('spreed', 'ing_servers');
		$ing = json_decode($config, true);
		if (!is_array($ing) || !isset($ing['servers'])) {
			return [];
		}

		return $ing['servers'];
	}

	
	public function getingSecret(): string {
		$config = $this->config->getAppValue('spreed', 'ing_servers');
		$ing = json_decode($config, true);

		if (!is_array($ing)) {
			return '';
		}

		return $ing['secret'];
	}

	public function getHideingWarning(): bool {
		return $this->config->getAppValue('spreed', 'hide_ing_warning', 'no') === 'yes';
	}

		public function getingTicket(?string $userId): string {
		if (empty($userId)) {
			$secret = $this->config->getAppValue('spreed', 'ing_ticket_secret');
		} else {
			$secret = $this->config->getUserValue($userId, 'spreed', 'ing_ticket_secret');
		}
		if (empty($secret)) {
			// Create secret lazily on first access.
			// TODO(fancycode): Is there a possibility for a race condition?
			$secret = $this->secureRandom->generate(255);
			if (empty($userId)) {
				$this->config->setAppValue('spreed', 'ing_ticket_secret', $secret);
			} else {
				$this->config->setUserValue($userId, 'spreed', 'ing_ticket_secret', $secret);
			}
		}

		// Format is "random:timestamp:userid:checksum" and "checksum" is the
		// SHA256-HMAC of "random:timestamp:userid" with the per-user secret.
		$random = $this->secureRandom->generate(16);
		$timestamp = $this->timeFactory->getTime();
		$data = $random . ':' . $timestamp . ':' . $userId;
		$hash = hash_hmac('sha256', $data, $secret);
		return $data . ':' . $hash;
	}

	/**
	 * @param string $userId
	 * @param string $ticket
	 * @return bool
	 */
	public function validateingTicket(?string $userId, string $ticket): bool {
		if (empty($userId)) {
			$secret = $this->config->getAppValue('spreed', 'ing_ticket_secret');
		} else {
			$secret = $this->config->getUserValue($userId, 'spreed', 'ing_ticket_secret');
		}
		if (empty($secret)) {
			return false;
		}

		$lastColon = strrpos($ticket, ':');
		if ($lastColon === false) {
			// Immediately reject invalid formats.
			return false;
		}

		// TODO(fancycode): Should we reject tickets that are too old?
		$data = substr($ticket, 0, $lastColon);
		$hash = hash_hmac('sha256', $data, $secret);
		return hash_equals($hash, substr($ticket, $lastColon + 1));
	}

}
