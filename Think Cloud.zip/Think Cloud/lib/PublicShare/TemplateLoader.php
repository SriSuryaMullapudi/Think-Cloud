<?php
declare(strict_types=1);


namespace OCA\Talk\PublicShare;

use OCP\EventDispatcher\IEventDispatcher;
use OCP\Files\FileInfo;
use OCP\Share\IShare;
use OCP\Util;
use Symfony\Component\EventDispatcher\GenericEvent;


class TemplateLoader {

	public static function register(IEventDispatcher $dispatcher): void {
		$dispatcher->addListener('OCA\Files_Sharing::loadAdditionalScripts', static function(GenericEvent $event) {
			/** @var IShare $share */
			$share = $event->getArgument('share');
			self::loadTalkSidebarUi($share);
		});
	}

	
	public static function loadTalkSidebarUi(IShare $share): void {
		$config = \OC::$server->getConfig();
		if ($config->getAppValue('spreed', 'conversations_files', '1') !== '1' ||
			$config->getAppValue('spreed', 'conversations_files_public_shares', '1') !== '1') {
			return;
		}

		if ($share->getNodeType() !== FileInfo::TYPE_FILE) {
			return;
		}

		Util::addStyle('spreed', 'merged-public-share');
		Util::addScript('spreed', 'merged-public-share');
	}

}
