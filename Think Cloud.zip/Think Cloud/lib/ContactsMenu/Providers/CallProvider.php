<?php
declare(strict_types=1);


namespace OCA\Talk\ContactsMenu\Providers;

use OCP\Contacts\ContactsMenu\IActionFactory;
use OCP\Contacts\ContactsMenu\IEntry;
use OCP\Contacts\ContactsMenu\IProvider;
use OCP\IL10N;
use OCP\IURLGenerator;
use OCP\IUser;
use OCP\IUserManager;

class CallProvider implements IProvider {

	
	private $actionFactory;

		private $urlGenerator;

	
	private $userManager;

	
	private $l10n;

	public function __construct(IActionFactory $actionFactory,
								IURLGenerator $urlGenerator,
								IL10N $l10n,
								IUserManager $userManager) {
		$this->actionFactory = $actionFactory;
		$this->urlGenerator = $urlGenerator;
		$this->userManager = $userManager;
		$this->l10n = $l10n;
	}

	public function process(IEntry $entry): void {
		$uid = $entry->getProperty('UID');

		if ($uid === null) {
			
			return;
		}

		if ($entry->getProperty('isLocalSystemBook') !== true) {
			
			return;
		}

		$user = $this->userManager->get($uid);
		if(!$user instanceof IUser) {
			
			return;
		}

		$talkAction = $this->l10n->t('Talk to %s', [$user->getDisplayName()]);
		$iconUrl = $this->urlGenerator->getAbsoluteURL($this->urlGenerator->imagePath('spreed', 'app-dark.svg'));
		$callUrl = $this->urlGenerator->linkToRouteAbsolute('spreed.Page.index') . '?callUser=' . $user->getUID();
		$action = $this->actionFactory->newLinkAction($iconUrl, $talkAction, $callUrl);
		$entry->addAction($action);
	}

}
