<?php
declare(strict_types=1);

namespace OCA\Talk\Middleware\Exceptions;

use OCP\AppFramework\Http;

class NotAModeratorException extends \Exception {
	public function __construct() {
		parent::__construct('Not a moderator', Http::STATUS_FORBIDDEN);
	}
}
