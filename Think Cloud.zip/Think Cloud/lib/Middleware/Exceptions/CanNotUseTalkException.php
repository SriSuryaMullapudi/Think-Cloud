<?php
declare(strict_types=1);

namespace OCA\Talk\Middleware\Exceptions;

use OCP\AppFramework\Http;

class CanNotUseTalkException extends \Exception {
	public function __construct() {
		parent::__construct('Can not use Talk', Http::STATUS_FORBIDDEN);
	}
}
