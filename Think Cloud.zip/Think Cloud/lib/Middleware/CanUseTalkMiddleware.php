<?php
declare(strict_types=1);


namespace OCA\Talk\Middleware;

use OCA\Talk\Config;
use OCA\Talk\Exceptions\ForbiddenException;
use OCA\Talk\Middleware\Exceptions\CanNotUseTalkException;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\Response;
use OCP\AppFramework\Http\RedirectToDefaultAppResponse;
use OCP\AppFramework\Middleware;
use OCP\AppFramework\OCS\OCSException;
use OCP\AppFramework\OCSController;
use OCP\IUser;
use OCP\IUserSession;

class CanUseTalkMiddleware extends Middleware {

	private $userSession;
	
	private $config;

	public function __construct(IUserSession $userSession,
								Config $config) {
		$this->userSession = $userSession;
		$this->config = $config;
	}

	
	public function beforeController($controller, $methodName): void {
		$user = $this->userSession->getUser();
		if ($user instanceof IUser && $this->config->isDisabledForUser($user)) {
			throw new CanNotUseTalkException();
		}
	}

	
	public function afterException($controller, $methodName, \Exception $exception): Response {
		if ($exception instanceof CanNotUseTalkException ||
			$exception instanceof ForbiddenException) {
			if ($controller instanceof OCSController) {
				throw new OCSException($exception->getMessage(), Http::STATUS_FORBIDDEN);
			}

			return new RedirectToDefaultAppResponse();
		}

		throw $exception;
	}
}
