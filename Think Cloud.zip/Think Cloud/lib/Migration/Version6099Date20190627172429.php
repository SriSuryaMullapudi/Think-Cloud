<?php

declare(strict_types=1);

namespace OCA\Talk\Migration;

use Closure;
use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version6099Date20190627172429 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, Closure $schemaClosure, array $options) {
		
		$schema = $schemaClosure();

		if ($schema->hasTable('talk_rooms')) {
			$table = $schema->getTable('talk_rooms');

			if (!$table->hasColumn('lobby_state')) {
				$table->addColumn('lobby_state', Type::INTEGER, [
					'notnull' => true,
					'length' => 6,
					'default' => 0,
				]);
				$table->addColumn('lobby_timer', Type::DATETIME, [
					'notnull' => false,
				]);
			}
		}

		return $schema;
	}
}
