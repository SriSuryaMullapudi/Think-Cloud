<?php
declare(strict_types=1);
namespace OCA\Talk\Migration;

use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version3003Date20180722152849 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
		
		$schema = $schemaClosure();

		$table = $schema->getTable('talk_participants');
		$table->addColumn('in_call', Type::INTEGER, [
			'default' => 0,
		]);

		return $schema;
	}
}
