<?php
declare(strict_types=1);

namespace OCA\Talk\Migration;

use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version2001Date20170921145301 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
		/** @var ISchemaWrapper $schema */
		$schema = $schemaClosure();

		$table = $schema->getTable('spreedme_rooms');
		$table->addColumn('password', Type::STRING, [
			'notnull' => false,
			'length' => 255,
			'default' => '',
		]);

		return $schema;
	}

}
