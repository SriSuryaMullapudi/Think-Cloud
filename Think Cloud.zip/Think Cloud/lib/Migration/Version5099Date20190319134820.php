<?php
declare(strict_types=1);


namespace OCA\Talk\Migration;

use Closure;
use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version5099Date20190319134820 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, Closure $schemaClosure, array $options) {
		
		$schema = $schemaClosure();

		if ($schema->hasTable('talk_rooms')) {
			$table = $schema->getTable('talk_rooms');

			if (!$table->hasColumn('read_only')) {
				$table->addColumn('read_only', Type::INTEGER, [
					'notnull' => true,
					'length' => 6,
					'default' => 0,
				]);
			}
		}

		return $schema;
	}

}
