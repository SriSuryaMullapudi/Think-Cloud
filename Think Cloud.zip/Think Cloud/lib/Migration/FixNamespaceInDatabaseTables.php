<?php
declare(strict_types=1);


namespace OCA\Talk\Migration;


use OCP\IDBConnection;
use OCP\Migration\IOutput;
use OCP\Migration\IRepairStep;

class FixNamespaceInDatabaseTables implements IRepairStep {

	
	protected $connection;

	public function __construct(IDBConnection $connection) {
		$this->connection = $connection;
	}

	public function getName(): string {
		return 'Fix the namespace in database tables';
	}

	public function run(IOutput $output): void {
		$update = $this->connection->getQueryBuilder();
		$update->update('jobs')
			->set('class', $update->createParameter('newClass'))
			->where($update->expr()->eq('id', $update->createParameter('id')));

		$query = $this->connection->getQueryBuilder();
		$query->select('id', 'class')
			->from('jobs')
			->where($query->expr()->like('class', $query->createNamedParameter(
				'%' . $this->connection->escapeLikeParameter('Spreed'). '%'
			)));

		$result = $query->execute();
		while ($row = $result->fetch()) {
			$oldClass = $row['class'];
			if (strpos($oldClass, 'OCA\\Spreed\\') !== 0) {
				continue;
			}

			$newClass = 'OCA\\Talk\\' . substr($oldClass, strlen('OCA\\Spreed\\'));

			$update->setParameter('newClass', $newClass)
				->setParameter('id', $row['id']);
			$update->execute();
		}
		$result->closeCursor();
	}
}
