<?php
declare(strict_types=1);

namespace OCA\Talk\Migration;

use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version3002Date20180319104030 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
		
		$schema = $schemaClosure();

		if (!$schema->hasTable('talk_guests')) {
			$table = $schema->createTable('talk_guests');

			$table->addColumn('session_hash', Type::STRING, [
				'notnull' => false,
				'length' => 64,
			]);
			$table->addColumn('display_name', Type::STRING, [
				'notnull' => false,
				'length' => 64,
				'default' => '',
			]);

			$table->addUniqueIndex(['session_hash'], 'tg_session_hash');
		}

		return $schema;
	}
}
