<?php
declare(strict_types=1);
namespace OCA\Talk\Migration;

use Doctrine\DBAL\Schema\SchemaException;
use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IDBConnection;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version7000Date20190724121136 extends SimpleMigrationStep {

	
	protected $connection;

	public function __construct(IDBConnection $connection) {
		$this->connection = $connection;
	}

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options) {
		
		$schema = $schemaClosure();

		$table = $schema->getTable('talk_participants');
		if (!$table->hasColumn('last_read_message')) {
			$table->addColumn('last_read_message', Type::BIGINT, [
				'default' => 0,
				'notnull' => false,
			]);
			$table->addColumn('last_mention_message', Type::BIGINT, [
				'default' => 0,
				'notnull' => false,
			]);
		}

		return $schema;
	}

	
	public function postSchemaChange(IOutput $output, \Closure $schemaClosure, array $options) {
		$query = $this->connection->getQueryBuilder();
		$query->select('m.user_id', 'm.object_id')
			->selectAlias($query->createFunction('MAX(' . $query->getColumnName('c.id') . ')'), 'last_comment')
			->from('comments_read_markers', 'm')
			->leftJoin('m', 'comments', 'c', $query->expr()->andX(
				$query->expr()->eq('c.object_id', 'm.object_id'),
				$query->expr()->eq('c.object_type', 'm.object_type'),
				$query->expr()->eq('c.creation_timestamp', 'm.marker_datetime')
			))
			->where($query->expr()->eq('m.object_type', $query->createNamedParameter('chat')))
			->groupBy('m.user_id', 'm.object_id');

		$update = $this->connection->getQueryBuilder();
		$update->update('talk_participants')
			->set('last_read_message', $update->createParameter('message_id'))
			->where($update->expr()->eq('user_id', $update->createParameter('user_id')))
			->andWhere($update->expr()->eq('room_id', $update->createParameter('room_id')));

		$result = $query->execute();
		while ($row = $result->fetch()) {
			$update->setParameter('message_id', (int) $row['last_comment'], IQueryBuilder::PARAM_INT)
				->setParameter('user_id', $row['user_id'])
				->setParameter('room_id', (int) $row['object_id'], IQueryBuilder::PARAM_INT);
			$update->execute();
		}
		$result->closeCursor();

		
		$default = $this->connection->getQueryBuilder();
		$default->update('talk_participants')
			->set('last_read_message', $default->createNamedParameter(-1))
			->where($default->expr()->isNotNull('user_id'))
			->andWhere($default->expr()->eq('last_read_message', $default->createNamedParameter(0)));
		$default->execute();
	}
}
