<?php
declare(strict_types=1);

namespace OCA\Talk\Migration;

use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version2001Date20171026141336 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
		/** @var ISchemaWrapper $schema */
		$schema = $schemaClosure();

		if ($schema->hasTable('videocalls_signaling')) {
			$schema->dropTable('videocalls_signaling');
		}

		if ($schema->hasTable('spreedme_rooms')) {
			$schema->dropTable('spreedme_rooms');
		}

		if ($schema->hasTable('spreedme_room_participants')) {
			$schema->dropTable('spreedme_room_participants');
		}

		return $schema;
	}
}
