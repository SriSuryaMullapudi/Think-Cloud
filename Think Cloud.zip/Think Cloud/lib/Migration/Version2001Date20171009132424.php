<?php
declare(strict_types=1);
namespace OCA\Talk\Migration;

use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version2001Date20171009132424 extends SimpleMigrationStep {

		public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
		
		$schema = $schemaClosure();

		$table = $schema->getTable('spreedme_rooms');
		$table->addColumn('activeSince', Type::DATETIME, [
			'notnull' => false,
		]);
		$table->addColumn('activeGuests', Type::INTEGER, [
			'notnull' => true,
			'length' => 4,
			'default' => 0,
			'unsigned' => true,
		]);

		return $schema;
	}

}
