<?php

namespace OCA\Talk\Migration;

use OCA\Talk\Model\Command;
use OCA\Talk\Service\CommandService;
use OCP\AppFramework\Db\DoesNotExistException;
use OCP\Migration\IOutput;
use OCP\Migration\IRepairStep;

class CreateHelpCommand implements IRepairStep {

	
	protected $service;

	public function __construct(CommandService $service) {
		$this->service = $service;
	}

	public function getName(): string {
		return 'Create help command';
	}

	public function run(IOutput $output): void {
		try {
			$this->service->find('', 'help');
		} catch (DoesNotExistException $e) {
			$this->service->create(
				'',
				'help',
				'talk',
				'',
				Command::RESPONSE_USER,
				Command::ENABLED_ALL
			);
		}
	}
}
