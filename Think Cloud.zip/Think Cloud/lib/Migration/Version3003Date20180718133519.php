<?php
declare(strict_types=1);

namespace OCA\Talk\Migration;

use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\IDBConnection;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version3003Date20180718133519 extends SimpleMigrationStep {

	
	protected $connection;

	public function __construct(IDBConnection $connection) {
		$this->connection = $connection;
	}

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
				$schema = $schemaClosure();

		$table = $schema->getTable('talk_rooms');

		if (!$table->hasColumn('last_message')) {
			$table->addColumn('last_message', Type::BIGINT, [
				'notnull' => false,
				'default' => 0,
			]);
		}

		return $schema;
	}

	
	public function postSchemaChange(IOutput $output, \Closure $schemaClosure, array $options): void {
		$update = $this->connection->getQueryBuilder();
		$update->update('talk_rooms')
			->set('last_message', $update->createParameter('message'))
			->where($update->expr()->eq('id', $update->createParameter('room')));

		$query = $this->connection->getQueryBuilder();
		$query->selectAlias($query->createFunction('MAX(' . $query->getColumnName('id') . ')'), 'message')
			->addSelect('object_id')
			->from('comments')
			->where($query->expr()->eq('object_type', $query->createNamedParameter('chat')))
			->groupBy('object_id');

		$result = $query->execute();
		while ($row = $result->fetch()) {
			$update->setParameter('message', $row['message'])
				->setParameter('room', $row['object_id']);
			$update->execute();
		}
		$result->closeCursor();
	}
}
