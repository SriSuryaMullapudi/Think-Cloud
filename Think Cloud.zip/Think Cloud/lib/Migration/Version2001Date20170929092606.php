<?php
declare(strict_types=1);
namespace OCA\Talk\Migration;

use OCP\IConfig;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version2001Date20170929092606 extends SimpleMigrationStep {

	
	protected $config;

	public function __construct(IConfig $config) {
		$this->config = $config;
	}

	
	public function preSchemaChange(IOutput $output, \Closure $schemaClosure, array $options): void {
		$stunServer = $this->config->getAppValue('spreed', 'stun_server', 'stun.nextcloud.com:443');
		$turnServer = [
			'server' => $this->config->getAppValue('spreed', 'turn_server'),
			'secret' => $this->config->getAppValue('spreed', 'turn_server_secret'),
			'protocols' => $this->config->getAppValue('spreed', 'turn_server_protocols'),
		];

		$this->config->setAppValue('spreed', 'stun_servers', json_encode([$stunServer]));
		if ($turnServer['server'] !== '' && $turnServer['secret'] !== '' && $turnServer['protocols'] !== '') {
			$this->config->setAppValue('spreed', 'turn_servers', json_encode([$turnServer]));
		}

		$this->config->deleteAppValue('spreed', 'stun_server');
		$this->config->deleteAppValue('spreed', 'turn_server');
		$this->config->deleteAppValue('spreed', 'turn_server_secret');
		$this->config->deleteAppValue('spreed', 'turn_server_protocols');
	}
}
