<?php

namespace OCA\Talk\Migration;

use Doctrine\DBAL\Schema\SchemaException;
use OCP\DB\ISchemaWrapper;
use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IDBConnection;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version7000Date20190724121137 extends SimpleMigrationStep {

	
	protected $connection;

	public function __construct(IDBConnection $connection) {
		$this->connection = $connection;
	}

	
	public function preSchemaChange(IOutput $output, \Closure $schemaClosure, array $options) {
		$query = $this->connection->getQueryBuilder();
		$query->select('p.user_id', 'p.room_id')
			->selectAlias($query->createFunction('MAX(' . $query->getColumnName('c.id') . ')'), 'last_mention_message')
			->from('talk_participants', 'p')
			->leftJoin('p', 'comments', 'c', $query->expr()->andX(
				$query->expr()->eq('c.object_id', $query->expr()->castColumn('p.room_id', IQueryBuilder::PARAM_STR)),
				$query->expr()->eq('c.object_type', $query->createNamedParameter('chat')),
				$query->expr()->eq('c.creation_timestamp', 'p.last_mention')
			))
			->where($query->expr()->isNotNull('p.user_id'))
			->groupBy('p.user_id', 'p.room_id');

		$update = $this->connection->getQueryBuilder();
		$update->update('talk_participants')
			->set('last_mention_message', $update->createParameter('message_id'))
			->where($update->expr()->eq('user_id', $update->createParameter('user_id')))
			->andWhere($update->expr()->eq('room_id', $update->createParameter('room_id')));

		$result = $query->execute();
		while ($row = $result->fetch()) {
			$update->setParameter('message_id', (int) $row['last_mention_message'], IQueryBuilder::PARAM_INT)
				->setParameter('user_id', $row['user_id'])
				->setParameter('room_id', (int) $row['room_id'], IQueryBuilder::PARAM_INT);
			$update->execute();
		}
		$result->closeCursor();
	}

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options) {
		
		$schema = $schemaClosure();

		$table = $schema->getTable('talk_participants');
		if ($table->hasColumn('last_mention')) {
			$table->dropColumn('last_mention');
		}

		return $schema;
	}
}
