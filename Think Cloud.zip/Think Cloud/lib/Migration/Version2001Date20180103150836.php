<?php
declare(strict_types=1);
namespace OCA\Talk\Migration;

use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version2001Date20180103150836 extends SimpleMigrationStep {

		public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
		
		$schema = $schemaClosure();

		$table = $schema->getTable('talk_rooms');
		if ($table->hasColumn('activeSince')) {
			$table->dropColumn('activeSince');
			$table->dropColumn('activeGuests');
		}

		$table = $schema->getTable('talk_participants');
		if ($table->hasColumn('userId')) {
			$table->dropColumn('userId');
			$table->dropColumn('roomId');
			$table->dropColumn('lastPing');
			$table->dropColumn('sessionId');
			$table->dropColumn('participantType');
			$table->dropColumn('inCall');
		}

		return $schema;
	}
}
