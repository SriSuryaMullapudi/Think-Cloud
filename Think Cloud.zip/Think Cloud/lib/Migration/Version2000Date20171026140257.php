<?php
declare(strict_types=1);
namespace OCA\Talk\Migration;

use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IConfig;
use OCP\IDBConnection;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;
use OCP\Security\ISecureRandom;

class Version2000Date20171026140257 extends SimpleMigrationStep {

	
	protected $connection;

	
	protected $config;

	
	protected $secureRandom;

	
	protected $tokens;

	public function __construct(IDBConnection $connection,
								IConfig $config,
								ISecureRandom $secureRandom) {
		$this->connection = $connection;
		$this->config = $config;
		$this->secureRandom = $secureRandom;
		$this->tokens = [];
	}

	
	public function postSchemaChange(IOutput $output, \Closure $schemaClosure, array $options): void {

		if (version_compare($this->config->getAppValue('spreed', 'installed_version', '0.0.0'), '2.0.0', '<')) {
			
			return;
		}

		$chars = str_replace(['l', '0', '1'], '', ISecureRandom::CHAR_LOWER . ISecureRandom::CHAR_DIGITS);
		$entropy = (int) $this->config->getAppValue('spreed', 'token_entropy', 8);

		$update = $this->connection->getQueryBuilder();
		$update->update('spreedme_rooms')
			->set('token', $update->createParameter('token'))
			->where($update->expr()->eq('id', $update->createParameter('room_id')));

		$query = $this->connection->getQueryBuilder();
		$query->select('*')
			->from('spreedme_rooms')
			->where($query->expr()->emptyString('token'))
			->orWhere($query->expr()->isNull('token'));
		$result = $query->execute();

		$output->startProgress();
		while ($row = $result->fetch()) {
			$output->advance();

			$token = $this->getNewToken($entropy, $chars);

			$update->setParameter('token', $token)
				->setParameter('room_id', (int) $row['id'], IQueryBuilder::PARAM_INT)
				->execute();
		}
		$output->finishProgress();

	}

		protected function getNewToken(int $entropy, string $chars): string {
		$token = $this->secureRandom->generate($entropy, $chars);
		while (isset($this->tokens[$token])) {
			$token = $this->secureRandom->generate($entropy, $chars);
		}
		$this->tokens[$token] = $token;
		return $token;
	}
}
