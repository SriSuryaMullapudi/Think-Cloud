<?php
declare(strict_types=1);
namespace OCA\Talk\Migration;

use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version2001Date20171031102049 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
		/** @var ISchemaWrapper $schema */
		$schema = $schemaClosure();


		$table = $schema->getTable('talk_participants');
		$table->addColumn('inCall', Type::BOOLEAN, [
			'default' => 0,
		]);

		return $schema;
	}

}
