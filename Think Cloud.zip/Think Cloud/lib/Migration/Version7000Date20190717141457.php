<?php
declare(strict_types=1);

namespace OCA\Talk\Migration;

use Closure;
use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version7000Date20190717141457 extends SimpleMigrationStep {

	
	public function changeSchema(IOutput $output, Closure $schemaClosure, array $options) {
		
		$schema = $schemaClosure();

		$table = $schema->getTable('talk_participants');
		if (!$table->hasColumn('last_joined_call')) {
			$table->addColumn('last_joined_call', Type::DATETIME, [
				'notnull' => false,
			]);
		}

		return $schema;
	}
}
