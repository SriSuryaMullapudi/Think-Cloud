<?php
declare(strict_types=1);

namespace OCA\Talk\Migration;

use Doctrine\DBAL\Types\Type;
use OCP\DB\ISchemaWrapper;
use OCP\Migration\SimpleMigrationStep;
use OCP\Migration\IOutput;

class Version3003Date20180730080327 extends SimpleMigrationStep {

		public function changeSchema(IOutput $output, \Closure $schemaClosure, array $options): ?ISchemaWrapper {
				$schema = $schemaClosure();

		$table = $schema->getTable('talk_participants');
		if (!$table->hasColumn('last_mention')) {
			$table->addColumn('last_mention', Type::DATETIME, [
				'notnull' => false,
			]);
		}

		return $schema;
	}
}
