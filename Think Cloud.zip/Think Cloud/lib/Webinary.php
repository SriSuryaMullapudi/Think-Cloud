<?php
declare(strict_types=1);


namespace OCA\Talk;


class Webinary {

	public const LOBBY_NONE = 0;
	public const LOBBY_NON_MODERATORS = 1;

}
