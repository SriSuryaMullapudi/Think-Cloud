<?php
declare(strict_types=1);

namespace OCA\Talk\Model;


use OCA\Talk\Participant;
use OCA\Talk\Room;
use OCP\Comments\IComment;
use OCP\IL10N;
use OCP\IUser;

class Message {

		protected $room;

	
	protected $comment;

	
	protected $l;

	
	protected $participant;

	
	protected $visible = true;

	
	protected $type = '';

	
	protected $message = '';

	
	protected $rawMessage = '';

	
	protected $parameters = [];

	
	protected $actorType = '';

	
	protected $actorId = '';

	
	protected $actorDisplayName = '';

	public function __construct(Room $room,
								Participant $participant,
								IComment $comment,
								IL10N $l) {
		$this->room = $room;
		$this->participant = $participant;
		$this->comment = $comment;
		$this->l = $l;
	}

	
	public function getRoom(): Room {
		return $this->room;
	}

	public function getComment(): IComment {
		return $this->comment;
	}

	public function getL10n(): IL10N {
		return $this->l;
	}

	public function getParticipant(): Participant {
		return $this->participant;
	}

	

	public function setVisibility(bool $visible): void {
		$this->visible = $visible;
	}

	public function getVisibility(): bool {
		return $this->visible;
	}

	public function setMessage(string $message, array $parameters, string $rawMessage = ''): void {
		$this->message = $message;
		$this->parameters = $parameters;
		$this->rawMessage = $rawMessage;
	}

	public function getMessage(): string {
		return $this->message;
	}

	public function getMessageParameters(): array {
		return $this->parameters;
	}

	public function getMessageRaw(): string {
		return $this->rawMessage;
	}

	public function setMessageType(string $type): void {
		$this->type = $type;
	}

	public function getMessageType(): string {
		return $this->type;
	}

	public function setActor(string $type, string $id, string $displayName): void {
		$this->actorType = $type;
		$this->actorId = $id;
		$this->actorDisplayName = $displayName;
	}

	public function getActorType(): string {
		return $this->actorType;
	}

	public function getActorId(): string {
		return $this->actorId;
	}

	public function getActorDisplayName(): string {
		return $this->actorDisplayName;
	}

	
	public function isReplyable(): bool {
		return $this->getMessageType() !== 'system' &&
			$this->getMessageType() !== 'command' &&
			\in_array($this->getActorType(), ['users', 'guests']);
	}

	public function toArray(): array {
		return [
			'id' => (int) $this->getComment()->getId(),
			'token' => $this->getRoom()->getToken(),
			'actorType' => $this->getActorType(),
			'actorId' => $this->getActorId(),
			'actorDisplayName' => $this->getActorDisplayName(),
			'timestamp' => $this->getComment()->getCreationDateTime()->getTimestamp(),
			'message' => $this->getMessage(),
			'messageParameters' => $this->getMessageParameters(),
			'systemMessage' => $this->getMessageType() === 'system' ? $this->getMessageRaw() : '',
			'messageType' => $this->getMessageType(),
			'isReplyable' => $this->isReplyable(),
		];
	}
}
