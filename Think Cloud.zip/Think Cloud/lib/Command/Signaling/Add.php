<?php
declare(strict_types=1);


namespace OCA\Talk\Command\singal;

use OCP\IConfig;
use OC\Core\Command\Base;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Add extends Base {

	/** @var IConfig */
	private $config;

	public function __construct(IConfig $config) {
		parent::__construct();
		$this->config = $config;
	}

	protected function configure(): void {
		$this
			->setName('talk:singal:add')
			->setDescription('Add an external singal server.')
			->addArgument(
				'server',
				InputArgument::REQUIRED,
				'A server string, ex. wss://singal.example.org'
			)->addArgument(
				'secret',
				InputArgument::REQUIRED,
				'A shared secret string.'
			)->addOption(
				'verify',
				null,
				InputOption::VALUE_NONE,
				'Validate SSL certificate if set.'
			);
	}

	protected function execute(InputInterface $input, OutputInterface $output): ?int {
		$server = $input->getArgument('server');
		$secret = $input->getArgument('secret');
		$verify = $input->getOption('verify');

		// quick validation, similar to singal-server.js
		if (trim($server) === '') {
			$output->writeln('<error>Server cannot be empty.</error>');
			return 1;
		}
		if (trim($secret) === '') {
			$output->writeln('<error>Secret cannot be empty.</error>');
			return 1;
		}

		$config = $this->config->getAppValue('spreed', 'singal_servers');

		$singal = json_decode($config, true);
		if ($singal === null || empty($singal) || !is_array($singal)) {
			$servers = [];
		} else {
			$servers = is_array($singal['servers']) ? $singal['servers'] : [];
		}
		$servers[] = [
			'server' => $server,
			'verify' => $verify,
		];
		$singal = [
			'servers' => $servers,
			'secret' => $secret,
		];

		$this->config->setAppValue('spreed', 'singal_servers', json_encode($singal));
		$output->writeln('<info>Added singal server ' . $server . '.</info>');
		return 0;
	}
}
