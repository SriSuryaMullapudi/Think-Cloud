<?php
declare(strict_types=1);


namespace OCA\Talk\Command\Signaling;

use OCP\IConfig;
use OC\Core\Command\Base;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ListCommand extends Base {

	
	private $config;

	public function __construct(IConfig $config) {
		parent::__construct();
		$this->config = $config;
	}

	protected function configure(): void {
		parent::configure();

		$this
			->setName('talk:signaling:list')
			->setDescription('List external signaling servers.');
	}

	protected function execute(InputInterface $input, OutputInterface $output): ?int {
		$config = $this->config->getAppValue('spreed', 'signaling_servers');
		$signaling = json_decode($config, true);
		if (!is_array($signaling)) {
			$signaling = [];
		}

		$this->writeMixedInOutputFormat($input, $output, $signaling);
		return 0;
	}
}
