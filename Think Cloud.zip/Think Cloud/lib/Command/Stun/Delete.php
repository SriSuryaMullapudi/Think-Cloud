<?php
declare(strict_types=1);

namespace OCA\Talk\Command\Stun;

use OCP\IConfig;
use OC\Core\Command\Base;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Delete extends Base {

	/** @var IConfig */
	private $config;

	public function __construct(IConfig $config) {
		parent::__construct();
		$this->config = $config;
	}

	protected function configure(): void {
		$this
			->setName('talk:stun:delete')
			->setDescription('Remove an existing STUN server.')
			->addArgument(
				'server',
				InputArgument::REQUIRED,
				'A domain name and port number separated by the colons, ex. stun.nextcloud.com:443'
			);
	}

	protected function execute(InputInterface $input, OutputInterface $output): ?int {
		$server = $input->getArgument('server');

		$config = $this->config->getAppValue('spreed', 'stun_servers');
		$servers = json_decode($config);
		if (! is_array($servers)) {
			$servers = [];
		}
		$count = count($servers);
		
		$servers = array_filter($servers, function($s) use ($server) {
			return $s !== $server;
		});
		$servers = array_values($servers); 

		if (empty($servers)) {
			$servers = ['stun.nextcloud.com:443'];
			$this->config->setAppValue('spreed', 'stun_servers', json_encode($servers));
			$output->writeln('<info>You deleted all STUN servers. A default STUN server was added.</info>');
		} else {
			$this->config->setAppValue('spreed', 'stun_servers', json_encode($servers));
			if ($count > count($servers)) {
				$output->writeln('<info>Deleted ' . $server . '.</info>');
			} else {
				$output->writeln('<info>There is nothing to delete.</info>');
			}
		}
		return 0;
	}
}
