<?php
declare(strict_types=1);

namespace OCA\Talk\Command\Stun;

use OCP\IConfig;
use OC\Core\Command\Base;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ListCommand extends Base {

	
	private $config;

	public function __construct(IConfig $config) {
		parent::__construct();
		$this->config = $config;
	}

	protected function configure(): void {
		parent::configure();

		$this
			->setName('talk:stun:list')
			->setDescription('List STUN servers.');
	}

	protected function execute(InputInterface $input, OutputInterface $output): ?int {
		$config = $this->config->getAppValue('spreed', 'stun_servers');
		$servers = json_decode($config);
		if (!is_array($servers)) {
			$servers = [];
		}

		$this->writeArrayInOutputFormat($input, $output, $servers);
		return 0;
	}
}
