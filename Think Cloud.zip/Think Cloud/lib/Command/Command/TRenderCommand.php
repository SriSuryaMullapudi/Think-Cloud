<?php
declare(strict_types=1);

namespace OCA\Talk\Command\Command;

use OCA\Talk\Model\Command;
use OC\Core\Command\Base;
use Symfony\Component\Console\Helper\Table;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

trait TRenderCommand {

	protected function renderCommands(string $outputFormat, OutputInterface $output, array $commands, bool $showHelp = false): void {
		$result = array_map(function(Command $command) {
			return $command->asArray();
		}, $commands);

		if ($outputFormat === Base::OUTPUT_FORMAT_PLAIN) {
			if ($showHelp) {
				$output->writeln('Response values: 0 - No one,   1 - User,       2 - All');
				$output->writeln('Enabled values:  0 - Disabled, 1 - Moderators, 2 - Users, 3 - Guests');
				$output->writeln('');
			}

			$table = new Table($output);
			if (isset($result[0])) {
				$table->setHeaders(array_keys($result[0]));
			}
			$table->addRows($result);
			$table->render();
		} else {
			$this->writeMixedInOutputFormat($input, $output, $result);
		}
	}
}
