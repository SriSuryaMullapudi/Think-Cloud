<?php
declare(strict_types=1);

namespace OCA\Talk\Command\Command;

use OCA\Talk\Service\CommandService;
use OC\Core\Command\Base;
use OCP\AppFramework\Db\DoesNotExistException;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Delete extends Base {

	
	private $service;

	public function __construct(CommandService $service) {
		parent::__construct();
		$this->service = $service;
	}

	protected function configure():void {
		$this
			->setName('talk:command:delete')
			->setDescription('Remove an existing command')
			->addArgument(
				'command-id',
				InputArgument::REQUIRED
			);
	}

	protected function execute(InputInterface $input, OutputInterface $output) {
		$id = (int) $input->getArgument('command-id');

		try {
			$this->service->delete($id);
		} catch (DoesNotExistException $e) {
			$output->writeln('<error>The given command ID does not exist</error>');
			return 1;
		} catch (\InvalidArgumentException $e) {
			$output->writeln('<error>The help command cannot be deleted</error>');
			return 2;
		}
	}
}
