<?php
declare(strict_types=1);

namespace OCA\Talk\Command\Command;

use OCA\Talk\Service\CommandService;
use OC\Core\Command\Base;
use OCP\AppFramework\Db\DoesNotExistException;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class Update extends Base {

	use TRenderCommand;

	/** @var CommandService */
	private $service;

	public function __construct(CommandService $service) {
		parent::__construct();
		$this->service = $service;
	}

	protected function configure(): void {
		$this
			->setName('talk:command:update')
			->setDescription('Add a new command')
			->addArgument(
				'command-id',
				InputArgument::REQUIRED
			)
			->addArgument(
				'cmd',
				InputArgument::REQUIRED,
				'The command as used in the chat "/help" => "help"'
			)
			->addArgument(
				'name',
				InputArgument::REQUIRED,
				'Name of the user posting the response'
			)
			->addArgument(
				'script',
				InputArgument::REQUIRED,
				'Script to execute (Must be using absolute paths only)'
			)
			->addArgument(
				'response',
				InputArgument::REQUIRED,
				'Who should see the response: 0 - No one, 1 - User, 2 - All'
			)
			->addArgument(
				'enabled',
				InputArgument::REQUIRED,
				'Who can use this command: 0 - Disabled, 1 - Moderators, 2 - Users, 3 - Guests'
			)
		;
	}

	protected function execute(InputInterface $input, OutputInterface $output) {
		$id = (int) $input->getArgument('command-id');
		$cmd = $input->getArgument('cmd');
		$name = $input->getArgument('name');
		$script = $input->getArgument('script');
		$response = (int) $input->getArgument('response');
		$enabled = (int) $input->getArgument('enabled');

		try {
			$command = $this->service->update($id, $cmd, $name, $script, $response, $enabled);
		} catch (DoesNotExistException $e) {
			$output->writeln('<error>The given command ID does not exist</error>');
			return 1;
		} catch (\InvalidArgumentException $e) {
			switch ($e->getCode()) {
				case 0:
					$output->writeln('<error>The help command and predefined commands cannot be updated</error>');
					break;
				case 1:
					$output->writeln('<error>The command already exists or is invalid</error>');
					break;
				case 2:
					$output->writeln('<error>The name is invalid</error>');
					break;
				case 3:
					$output->writeln('<error>The script is invalid</error>');
					break;
				case 4:
					$output->writeln('<error>The response value is invalid</error>');
					break;
				case 5:
					$output->writeln('<error>The enabled value is invalid</error>');
					break;
				default:
					$output->writeln('<error>The command could not be updated</error>');
					break;
			}
			return 2;
		}


		$output->writeln('<info>Command updated</info>');
		$output->writeln('');
		$this->renderCommands(Base::OUTPUT_FORMAT_PLAIN, $output, [$command]);
	}
}
