<?php
declare(strict_types=1);
namespace OCA\Talk\Command\Turn;

use OCP\IConfig;
use OC\Core\Command\Base;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ListCommand extends Base {

	/** @var IConfig */
	private $config;

	public function __construct(IConfig $config) {
		parent::__construct();
		$this->config = $config;
	}

	protected function configure(): void {
		parent::configure();

		$this
			->setName('talk:turn:list')
			->setDescription('List TURN servers.');
	}

	protected function execute(InputInterface $input, OutputInterface $output): ?int {
		$config = $this->config->getAppValue('spreed', 'turn_servers');
		$servers = json_decode($config, true);
		if (!is_array($servers)) {
			$servers = [];
		}

		$this->writeMixedInOutputFormat($input, $output, $servers);
		return 0;
	}
}
