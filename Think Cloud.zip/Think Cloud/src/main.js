
import Vue from 'vue'
import App from './App'


import Vuex from 'vuex'
import store from './store'


import VueRouter from 'vue-router'
import router from './router/router'


import { generateFilePath } from '@nextcloud/router'
import { getRequestToken } from '@nextcloud/auth'


import contenteditableDirective from 'vue-contenteditable-directive'
import VueClipboard from 'vue-clipboard2'
import { translate, translatePlural } from '@nextcloud/l10n'
import VueObserveVisibility from 'vue-observe-visibility'

__webpack_nonce__ = btoa(getRequestToken())


__webpack_public_path__ = generateFilePath('spreed', '', 'js/')

Vue.prototype.t = translate
Vue.prototype.n = translatePlural
Vue.prototype.OC = OC
Vue.prototype.OCA = OCA

Vue.use(contenteditableDirective)
Vue.use(Vuex)
Vue.use(VueRouter)
Vue.use(VueClipboard)
Vue.use(VueObserveVisibility)

export default new Vue({
	el: '#content',
	store,
	router,
	propsData: {
		fileInfo: null,
	},
	render: h => h(App),
})
