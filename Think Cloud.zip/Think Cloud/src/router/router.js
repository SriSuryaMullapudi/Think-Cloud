
import Vue from 'vue'
import Router from 'vue-router'
import { generateUrl } from '@nextcloud/router'
import WelcomeView from '../views/WelcomeView.vue'
import MainView from '../views/MainView.vue'

Vue.use(Router)

export default new Router({
	mode: 'history',
		base: generateUrl('/', ''),
	linkActiveClass: 'active',
	routes: [
		{
			path: '/apps/spreed',
			name: 'root',
			component: WelcomeView,
			props: true,
		},
		{
			path: '/call/:token',
			name: 'conversation',
			component: MainView,
			props: true,
		},
	],
})
