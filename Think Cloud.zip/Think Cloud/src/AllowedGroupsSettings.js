import Vue from 'vue'
import AllowedGroups from './views/AdminSettings/AllowedGroups'

Vue.prototype.t = t
Vue.prototype.n = n
Vue.prototype.OC = OC
Vue.prototype.OCA = OCA
Vue.prototype.OCP = OCP

export default new Vue({
	el: '#allowed_groups',
	name: 'AllowedGroupsSettings',
	render: h => h(AllowedGroups),
})
