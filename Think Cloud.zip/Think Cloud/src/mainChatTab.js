import Vue from 'vue'
import App from './FilesSidebarTabApp'


import Vuex from 'vuex'
import store from './store'


import { generateFilePath } from '@nextcloud/router'
import { getRequestToken } from '@nextcloud/auth'


import contenteditableDirective from 'vue-contenteditable-directive'
import { translate, translatePlural } from '@nextcloud/l10n'

__webpack_nonce__ = btoa(getRequestToken())


__webpack_public_path__ = generateFilePath('spreed', '', 'js/')

Vue.prototype.t = translate
Vue.prototype.n = translatePlural
Vue.prototype.OC = OC
Vue.prototype.OCA = OCA

Vue.use(contenteditableDirective)
Vue.use(Vuex)

const newTab = () => new Vue({
	store,
	render: h => h(App),
})

if (!window.OCA.Talk) {
	window.OCA.Talk = {}
}
Object.assign(window.OCA.Talk, {
	fileInfo: null,
	newTab,
})
