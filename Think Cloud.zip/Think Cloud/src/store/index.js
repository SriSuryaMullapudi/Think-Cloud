

import Vue from 'vue'
import Vuex, { Store } from 'vuex'
import actorStore from './actorStore'
import conversationsStore from './conversationsStore'
import messagesStore from './messagesStore'
import participantsStore from './participantsStore'
import quoteReplyStore from './quoteReplyStore'
import sidebarStore from './sidebarStore'
import tokenStore from './tokenStore'

Vue.use(Vuex)

const mutations = {}

export default new Store({
	modules: {
		actorStore,
		conversationsStore,
		messagesStore,
		participantsStore,
		quoteReplyStore,
		sidebarStore,
		tokenStore,
	},

	mutations,

	strict: process.env.NODE_ENV !== 'production',
})
