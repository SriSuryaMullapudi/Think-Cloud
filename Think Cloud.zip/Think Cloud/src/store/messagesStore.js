
import Vue from 'vue'

const state = {
	messages: {
	},
}

const getters = {
	
	messagesList: (state) => (token) => {
		if (state.messages[token]) {
			return Object.values(state.messages[token])
		}
		return []
	},
	
	messages: (state) => (token) => {
		if (state.messages[token]) {
			return state.messages[token]
		}
		return {}
	},
	
	message: (state) => (token, id) => {
		if (state.messages[token][id]) {
			return state.messages[token][id]
		}
		return {}
	},
}

const mutations = {
	
	addMessage(state, message) {
		if (!state.messages[message.token]) {
			Vue.set(state.messages, message.token, {})
		}
		if (state.messages[message.token][message.id]) {
			Vue.set(state.messages[message.token], message.id,
				Object.assign(state.messages[message.token][message.id], message)
			)
		} else {
			Vue.set(state.messages[message.token], message.id, message)
		}
	},
	
	deleteMessage(state, message) {
		Vue.delete(state.messages[message.token], message.id)
	},
	
	addTemporaryMessage(state, message) {
		Vue.set(state.messages[message.token], message.id, message)
	},
}

const actions = {

	
	processMessage(context, message) {
		if (message.parent) {
			context.commit('addMessage', message.parent)
			message.parent = message.parent.id
		}
		context.commit('addMessage', message)
	},

	
	deleteMessage(context, message) {
		context.commit('deleteMessage', message)
	},

	
	addTemporaryMessage(context, message) {
		context.commit('addTemporaryMessage', message)
	},
}

export default { state, mutations, getters, actions }
