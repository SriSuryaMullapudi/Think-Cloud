import Vue from 'vue'
import { makePublic, makePrivate, changeLobbyState } from '../services/conversationsService'
import { getCurrentUser } from '@nextcloud/auth'
import { CONVERSATION, WEBINAR } from '../constants'

const getDefaultState = () => {
	return {
		conversations: {
		},
	}
}

const state = {
	conversations: {
	},
}

const getters = {
	conversations: state => state.conversations,
	conversationsList: state => Object.values(state.conversations),
}

const mutations = {
	
	addConversation(state, conversation) {
		Vue.set(state.conversations, conversation.token, conversation)
	},
	
	deleteConversation(state, conversation) {
		Vue.delete(state.conversations, conversation.token)
	},
	
	purgeConversationsStore(state) {
		Object.assign(state, getDefaultState())
	},
}

const actions = {
	
	addConversation(context, conversation) {
		context.commit('addConversation', conversation)

		const currentUser = getCurrentUser()
		context.dispatch('addParticipantOnce', {
			token: conversation.token,
			participant: {
				inCall: conversation.participantFlags,
				lastPing: conversation.lastPing,
				sessionId: conversation.sessionId,
				participantType: conversation.participantType,
				userId: currentUser ? currentUser.uid : '',
				displayName: currentUser && currentUser.displayName ? currentUser.displayName : '',
			},
		})
	},

	
	deleteConversation(context, conversation) {
		context.commit('deleteConversation', conversation)
	},
	
	purgeConversationsStore(context) {
		context.commit('purgeConversationsStore')
	},

	async toggleGuests({ commit, getters }, { token, allowGuests }) {
		const conversation = Object.assign({}, getters.conversations[token])
		if (!conversation) {
			return
		}

		if (allowGuests) {
			await makePublic(token)
			conversation.type = CONVERSATION.TYPE.PUBLIC
		} else {
			await makePrivate(token)
			conversation.type = CONVERSATION.TYPE.GROUP
		}

		commit('addConversation', conversation)
	},

	async toggleLobby({ commit, getters }, { token, enableLobby }) {
		const conversation = Object.assign({}, getters.conversations[token])
		if (!conversation) {
			return
		}

		if (enableLobby) {
			await changeLobbyState(token, WEBINAR.LOBBY.NON_MODERATORS)
			conversation.lobbyState = WEBINAR.LOBBY.NON_MODERATORS
		} else {
			await changeLobbyState(token, WEBINAR.LOBBY.NONE)
			conversation.lobbyState = WEBINAR.LOBBY.NONE
		}

		commit('addConversation', conversation)
	},
}

export default { state, mutations, getters, actions }
