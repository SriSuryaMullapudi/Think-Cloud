

import sha1 from 'crypto-js/sha1'
import { PARTICIPANT } from '../constants'

const state = {
	userId: null,
	sessionId: null,
	sessionHash: null,
	actorId: null,
	actorType: null,
	displayName: '',
}

const getters = {
	getUserId: (state) => () => {
		return state.userId
	},
	getSessionId: (state) => () => {
		return state.sessionId
	},
	getSessionHash: (state) => () => {
		return state.sessionHash
	},
	getActorId: (state) => () => {
		return state.actorId
	},
	getActorType: (state) => () => {
		return state.actorType
	},
	getDisplayName: (state) => () => {
		return state.displayName
	},
	getParticipantIdentifier: (state) => () => {
		if (state.actorType === 'guests') {
			return {
				sessionId: state.sessionId,
			}
		}
		return {
			participant: state.userId,
		}
	},
}

const mutations = {
	
	setUserId(state, userId) {
		state.userId = userId
		state.actorId = userId
	},
	
	setSessionId(state, sessionId) {
		state.sessionId = sessionId
		state.sessionHash = sha1(sessionId)
	},
	
	setActorId(state, actorId) {
		state.actorId = actorId
	},
	
	setDisplayName(state, displayName) {
		state.displayName = displayName
	},
	
	setActorType(state, actorType) {
		state.actorType = actorType
	},
}

const actions = {

	
	setCurrentUser(context, user) {
		context.commit('setUserId', user.uid)
		context.commit('setDisplayName', user.displayName || user.uid)
		context.commit('setActorType', 'users')
	},

		setCurrentParticipant(context, participant) {
		context.commit('setSessionId', participant.sessionId)

		if (participant.participantType === PARTICIPANT.TYPE.GUEST
			|| participant.participantType === PARTICIPANT.TYPE.GUEST_MODERATOR) {
			context.commit('setUserId', null)
			context.commit('setActorType', 'guests')
			context.commit('setActorId', 'guest/' + context.getters.getSessionHash())
			// FIXME context.commit('setDisplayName', '')
		}
	},
}

export default { state, mutations, getters, actions }
