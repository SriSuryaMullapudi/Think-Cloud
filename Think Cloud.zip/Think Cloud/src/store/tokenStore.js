
const state = {
	token: '',
	fileIdForToken: null,
}

const getters = {
	getToken: (state) => () => {
		return state.token
	},
	getFileIdForToken: (state) => () => {
		return state.fileIdForToken
	},
}

const mutations = {
	
	updateToken(state, newToken) {
		state.token = newToken
	},

	
	updateTokenAndFileIdForToken(state, { newToken, newFileId }) {
		state.token = newToken
		state.fileIdForToken = newFileId
	},
}

const actions = {

	
	updateToken(context, newToken) {
		context.commit('updateToken', newToken)
	},

		updateTokenAndFileIdForToken(context, { newToken, newFileId }) {
		context.commit('updateTokenAndFileIdForToken', { newToken, newFileId })
	},
}

export default { state, mutations, getters, actions }
