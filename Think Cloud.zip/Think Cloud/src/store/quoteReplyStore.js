
import Vue from 'vue'

const state = {
	messagesToBeReplied: {},
}

const getters = {
	getMessageToBeReplied: (state) => (token) => {
		if (state.messagesToBeReplied[token]) {
			return state.messagesToBeReplied[token]
		}
	},
}

const mutations = {
	
	addMessageToBeReplied(state, messageToBeReplied) {
		Vue.set(state.messagesToBeReplied, [messageToBeReplied.token], messageToBeReplied)
	},
		removeMessageToBeReplied(state, token) {
		Vue.delete(state.messagesToBeReplied, token)
	},
}

const actions = {

	
	addMessageToBeReplied(context, messageToBeReplied) {
		context.commit('addMessageToBeReplied', messageToBeReplied)
	},
	
	removeMessageToBeReplied(context, token) {
		context.commit('removeMessageToBeReplied', token)
	},
}

export default { state, mutations, getters, actions }
