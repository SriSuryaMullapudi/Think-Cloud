
const state = {
	show: true,
}

const getters = {
	getSidebarStatus: (state) => () => {
		return state.show
	},
}

const mutations = {
	
	showSidebar(state) {
		state.show = true
	},
	
	hideSidebar(state) {
		state.show = false
	},
}

const actions = {

	
	showSidebar(context) {
		context.commit('showSidebar')
	},
	
	hideSidebar(context) {
		context.commit('hideSidebar')
	},
}

export default { state, mutations, getters, actions }
