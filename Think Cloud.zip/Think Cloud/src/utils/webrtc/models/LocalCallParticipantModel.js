
export default function LocalCallParticipantModel() {

	this.attributes = {
		peerId: null,
		guestName: null,
	}

}

LocalCallParticipantModel.prototype = {

	set: function(key, value) {
		this.attributes[key] = value
	},

	setWebRtc: function(webRtc) {
		this._webRtc = webRtc

		this.set('peerId', this._webRtc.connection.getSessionId())
		this.set('guestName', null)
	},

	setGuestName: function(guestName) {
		if (!this._webRtc) {
			throw new Error('WebRtc not initialized yet')
		}

		this.set('guestName', guestName)

		this._webRtc.sendDirectlyToAll('status', 'nickChanged', guestName)
	},

}
