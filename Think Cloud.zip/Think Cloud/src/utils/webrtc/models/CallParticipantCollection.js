

import CallParticipantModel from './CallParticipantModel'

export default function CallParticipantCollection() {

	this.callParticipantModels = []

}

CallParticipantCollection.prototype = {

	add: function(options) {
		const callParticipantModel = new CallParticipantModel(options)
		this.callParticipantModels.push(callParticipantModel)

		return callParticipantModel
	},

	get: function(peerId) {
		return this.callParticipantModels.find(function(callParticipantModel) {
			return callParticipantModel.attributes.peerId === peerId
		})
	},

	remove: function(peerId) {
		const index = this.callParticipantModels.findIndex(function(callParticipantModel) {
			return callParticipantModel.attributes.peerId === peerId
		})
		if (index !== -1) {
			this.callParticipantModels.splice(index, 1)
		}
	},

}
