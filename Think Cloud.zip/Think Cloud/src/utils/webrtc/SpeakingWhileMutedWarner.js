export default function SpeakingWhileMutedWarner(model, view) {
	model.on('change:speakingWhileMuted', this._handleSpeakingWhileMutedChange.bind(this))

	this._view = view
}
SpeakingWhileMutedWarner.prototype = {

	_handleSpeakingWhileMutedChange: function(model, speakingWhileMuted) {
		if (speakingWhileMuted) {
			this._handleSpeakingWhileMuted()
		} else {
			this._handleStoppedSpeakingWhileMuted()
		}
	},

	_handleSpeakingWhileMuted: function() {
		this._startedSpeakingTimeout = setTimeout(function() {
			delete this._startedSpeakingTimeout

			this._showWarning()
		}.bind(this), 3000)
	},

	_handleStoppedSpeakingWhileMuted: function() {
		if (this._startedSpeakingTimeout) {
			clearTimeout(this._startedSpeakingTimeout)
			delete this._startedSpeakingTimeout
		}

		this._hideWarning()
	},

	_showWarning: function() {
		const message = t('spreed', 'You seem to be talking while muted, please unmute yourself for others to hear you')

		if (!document.hidden) {
			this._showNotification(message)
		} else {
			this._pendingBrowserNotification = true

			this._showBrowserNotification(message).catch(function() {
				if (this._pendingBrowserNotification) {
					this._pendingBrowserNotification = false

					this._showNotification(message)
				}
			}.bind(this))
		}
	},

	_showNotification: function(message) {
		if (this._notification) {
			return
		}

		this._view.setSpeakingWhileMutedNotification(message)
		this._notification = true
	},

	_showBrowserNotification: function(message) {
		return new Promise(function(resolve, reject) {
			if (this._browserNotification) {
				resolve()

				return
			}

			if (!Notification) {
				// The browser does not support the Notification API.
				reject()

				return
			}

			if (Notification.permission === 'denied') {
				reject()

				return
			}

			if (Notification.permission === 'granted') {
				this._pendingBrowserNotification = false
				this._browserNotification = new Notification(message)
				resolve()

				return
			}

			Notification.requestPermission().then(function(permission) {
				if (permission === 'granted') {
					if (this._pendingBrowserNotification) {
						this._pendingBrowserNotification = false
						this._browserNotification = new Notification(message)
					}
					resolve()
				} else {
					reject()
				}
			}.bind(this))
		}.bind(this))
	},

	_hideWarning: function() {
		this._pendingBrowserNotification = false

		if (this._notification) {
			this._view.setSpeakingWhileMutedNotification(null)

			this._notification = false
		}

		if (this._browserNotification) {
			this._browserNotification.close()

			this._browserNotification = null
		}
	},

}
