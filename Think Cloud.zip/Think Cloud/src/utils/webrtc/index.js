
import Signaling from '../signaling'
import initWebRtc from './webrtc'
import CallParticipantCollection from './models/CallParticipantCollection'
import LocalCallParticipantModel from './models/LocalCallParticipantModel'
import LocalMediaModel from './models/LocalMediaModel'
import { PARTICIPANT } from '../../constants'
import { EventBus } from '../../services/EventBus'

let signaling = null
let webRtc = null
const callParticipantCollection = new CallParticipantCollection()
const localCallParticipantModel = new LocalCallParticipantModel()
const localMediaModel = new LocalMediaModel()

let pendingConnectSignaling = null

async function connectSignaling() {
	if (signaling) {
		return
	}

	if (pendingConnectSignaling) {
		return pendingConnectSignaling
	}

	pendingConnectSignaling = new Promise((resolve, reject) => {
		Signaling.loadSettings(null).then(() => {
			signaling = Signaling.createConnection()

			EventBus.$emit('signalingConnectionEstablished')

			pendingConnectSignaling = null

			resolve()
		})
	})

	return pendingConnectSignaling
}

async function getSignaling() {
	await connectSignaling()

	return signaling
}

let currentToken = null
let startedCall = null

function startCall(configuration) {
	let flags = PARTICIPANT.CALL_FLAG.IN_CALL
	if (configuration) {
		if (configuration.audio) {
			flags |= PARTICIPANT.CALL_FLAG.WITH_AUDIO
		}
		if (configuration.video && signaling.getSendVideoIfAvailable()) {
			flags |= PARTICIPANT.CALL_FLAG.WITH_VIDEO
		}
	}

	signaling.joinCall(currentToken, flags)

	startedCall()
}

function setupWebRtc() {
	if (webRtc) {
		return
	}

	webRtc = initWebRtc(signaling, callParticipantCollection)
	localCallParticipantModel.setWebRtc(webRtc)
	localMediaModel.setWebRtc(webRtc)

	webRtc.on('localMediaStarted', function(configuration) {
		startCall(configuration)
	})
	webRtc.on('localMediaError', function() {
		startCall(null)
	})
}

async function joinCall(token) {
	await connectSignaling()

	setupWebRtc()

	currentToken = token

	return new Promise((resolve, reject) => {
		startedCall = resolve

		webRtc.startMedia(token)
	})
}

export {
	callParticipantCollection,
	localCallParticipantModel,
	localMediaModel,
	connectSignaling,
	getSignaling,
	joinCall,
}
