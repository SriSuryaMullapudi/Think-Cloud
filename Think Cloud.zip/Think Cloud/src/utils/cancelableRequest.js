
import axios from '@nextcloud/axios'


const CancelableRequest = function(request) {
	
	const CancelToken = axios.CancelToken
	const source = CancelToken.source()

	
	const fetch = async function(data, options) {
		return request(
			data,
			Object.assign({ cancelToken: source.token }, options)
		)
	}
	return {
		request: fetch,
		cancel: source.cancel,
	}
}

export default CancelableRequest
