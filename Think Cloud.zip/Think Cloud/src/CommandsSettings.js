
import Vue from 'vue'
import Commands from './views/AdminSettings/Commands'

Vue.prototype.t = t
Vue.prototype.n = n
Vue.prototype.OC = OC
Vue.prototype.OCA = OCA
Vue.prototype.OCP = OCP

export default new Vue({
	el: '#chat_commands',
	name: 'CommandsSettings',
	render: h => h(Commands),
})
