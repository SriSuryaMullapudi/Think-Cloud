

import Vue from 'vue'
import SignalingServers from './views/AdminSettings/SignalingServers'

Vue.prototype.t = t
Vue.prototype.n = n
Vue.prototype.OC = OC
Vue.prototype.OCA = OCA
Vue.prototype.OCP = OCP

export default new Vue({
	el: '#signaling_server',
	name: 'SignalingServerSettings',
	render: h => h(SignalingServers),
})
