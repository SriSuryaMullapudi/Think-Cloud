
import axios from '@nextcloud/axios'
import { generateOcsUrl } from '@nextcloud/router'


const fetchSignalingSettings = async function(token) {
	// TODO: use token to get signaling settings depending on the conversation
	// This would allow to not use the HPB in one-to-one conversations where it
	// brings not much of an advantage. Make sure participants from one
	// conversation all use the same signaling server, etc.
	return axios.get(generateOcsUrl('apps/spreed/api/v1/signaling', 2) + 'settings')
}

export {
	fetchSignalingSettings,
}
