

import axios from '@nextcloud/axios'
import { generateOcsUrl } from '@nextcloud/router'


const fetchMessages = async function({ token }, options) {
	const response = await axios.get(generateOcsUrl('apps/spreed/api/v1/chat', 2) + token + '?lookIntoFuture=0', options)
	return response
}


const lookForNewMessages = async({ token, lastKnownMessageId }, options) => {
	const response = await axios.get(generateOcsUrl('apps/spreed/api/v1/chat', 2) + token + '?lookIntoFuture=1' + '&includeLastKnown=0' + `&lastKnownMessageId=${lastKnownMessageId}`, options)
	return response
}

const postNewMessage = async function({ token, message, parent }) {
	const response = await axios.post(generateOcsUrl('apps/spreed/api/v1/chat', 2) + token, { message, actorDisplayName: '', replyTo: parent })
	return response
}

export {
	fetchMessages,
	lookForNewMessages,
	postNewMessage,
}
