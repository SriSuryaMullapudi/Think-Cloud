import axios from '@nextcloud/axios'
import { generateOcsUrl } from '@nextcloud/router'
import { CONVERSATION, SHARE } from '../constants'


const fetchConversations = async function() {
	try {
		const response = await axios.get(generateOcsUrl('apps/spreed/api/v1', 2) + 'room')
		return response
	} catch (error) {
		console.debug('Error while fetching conversations: ', error)
	}
}


const fetchConversation = async function(token) {
	try {
		const response = await axios.get(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}`)
		return response
	} catch (error) {
		console.debug('Error while fetching a conversation: ', error)
	}
}


const searchPossibleConversations = async function(searchText) {
	try {
		const response = await axios.get(generateOcsUrl('core/autocomplete', 2) + `get` + `?format=json` + `&search=${searchText}` + `&itemType=call` + `&itemId=new` + `&shareTypes[]=${SHARE.TYPE.USER}&shareTypes[]=${SHARE.TYPE.GROUP}&shareTypes[]=${SHARE.TYPE.CIRCLE}`)
		return response
	} catch (error) {
		console.debug('Error while searching possible conversations: ', error)
	}
}

const createOneToOneConversation = async function(userId) {
	try {
		const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room`, { roomType: CONVERSATION.TYPE.ONE_TO_ONE, invite: userId })
		return response
	} catch (error) {
		console.debug('Error creating new one to one conversation: ', error)
	}
}


const createGroupConversation = async function(invite, source) {
	try {
		const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room`, { roomType: CONVERSATION.TYPE.GROUP, invite, source: source || 'groups' })
		return response
	} catch (error) {
		console.debug('Error creating new group conversation: ', error)
	}
}


const createPrivateConversation = async function(conversationName) {
	try {
		const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room`, { roomType: CONVERSATION.TYPE.GROUP, roomName: conversationName })
		return response
	} catch (error) {
		console.debug('Error creating new private conversation: ', error)
	}
}


const createPublicConversation = async function(conversationName) {
	try {
		const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room`, { roomType: CONVERSATION.TYPE.PUBLIC, roomName: conversationName })
		return response
	} catch (error) {
		console.debug('Error creating new public conversation: ', error)
	}
}

const deleteConversation = async function(token) {
	try {
		const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}`)
		return response
	} catch (error) {
		console.debug('Error while deleting the conversation: ', error)
	}
}


const addToFavorites = async function(token) {
	try {
		const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/favorite`)
		return response
	} catch (error) {
		console.debug('Error while adding the conversation to favorites: ', error)
	}
}


const removeFromFavorites = async function(token) {
	try {
		const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/favorite`)
		return response
	} catch (error) {
		console.debug('Error while removing the conversation from favorites: ', error)
	}
}


const setNotificationLevel = async function(token, level) {
	try {
		const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/notify`, { level })
		return response
	} catch (error) {
		console.debug('Error while setting the notification level: ', error)
	}
}


const makePublic = async function(token) {
	try {
		const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/public`)
		return response
	} catch (error) {
		console.debug('Error while making the conversation public: ', error)
	}
}


const makePrivate = async function(token) {
	try {
		const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/public`)
		return response
	} catch (error) {
		console.debug('Error while making the conversation private: ', error)
	}
}


const changeLobbyState = async function(token, newState) {
	try {
		const response = await axios.put(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/webinar/lobby`, {
			state: newState,
		})
		return response
	} catch (error) {
		console.debug('Error while updating webinar lobby: ', error)
	}
}

export {
	fetchConversations,
	fetchConversation,
	searchPossibleConversations,
	createOneToOneConversation,
	createGroupConversation,
	createPrivateConversation,
	createPublicConversation,
	deleteConversation,
	addToFavorites,
	removeFromFavorites,
	setNotificationLevel,
	makePublic,
	makePrivate,
	changeLobbyState,
}
