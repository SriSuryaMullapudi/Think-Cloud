
import axios from '@nextcloud/axios'
import { generateOcsUrl } from '@nextcloud/router'


const getFileConversation = async function({ fileId }, options) {
	try {
		const response = await axios.get(generateOcsUrl('apps/spreed/api/v1', 2) + `file/${fileId}`)
		return response
	} catch (error) {
		console.debug('Error while getting the token: ', error)
	}
}

export {
	getFileConversation,
}
