
import axios from '@nextcloud/axios'
import { generateOcsUrl } from '@nextcloud/router'
import { joinCall as webRtcJoinCall, getSignaling } from '../utils/webrtc/index'

const joinCall = async function(token, flags) {
	try {
		// FIXME flags is ignored?
		await webRtcJoinCall(token)
	} catch (error) {
		console.debug('Error while joining call: ', error)
	}
}


const leaveCall = async function(token) {
	try {
		const signaling = await getSignaling()

		await signaling.leaveCurrentCall()
	} catch (error) {
		console.debug('Error while leaving call: ', error)
	}
}

const fetchPeers = async function(token) {
	try {
		const response = await axios.get(generateOcsUrl('apps/spreed/api/v1', 2) + `call/${token}`)
		return response
	} catch (error) {
		console.debug('Error while fetching the peers: ', error)
	}
}

export {
	joinCall,
	leaveCall,
	fetchPeers,
}
