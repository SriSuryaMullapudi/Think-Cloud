
import axios from '@nextcloud/axios'
import { generateOcsUrl } from '@nextcloud/router'
import { getSignaling } from '../utils/webrtc/index'
import { EventBus } from '../services/EventBus'


const joinConversation = async(token) => {
	try {
		const signaling = await getSignaling()

		signaling.joinRoom(token).then(() => {
			EventBus.$emit('joinedConversation')
		})

		// FIXME Signaling should not handle joining a conversation
		// const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/participants/active`)
		// return response
	} catch (error) {
		console.debug(error)
	}
}


const leaveConversation = async function(token) {
	try {
		const signaling = await getSignaling()

		signaling.leaveRoom(token)
		// FIXME Signaling should not handle leaving a conversation
		// const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/participants/active`)
		// return response
	} catch (error) {
		console.debug(error)
	}
}

const addParticipant = async function(token, newParticipant, source) {
	const response = await axios.post(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/participants`, {
		newParticipant,
		source,
	})
	return response
}


const removeCurrentUserFromConversation = async function(token) {
	const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/participants/self`)
	return response
}

const removeUserFromConversation = async function(token, userId) {
	try {
		const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/participants`, {
			params: {
				participant: userId,
			},
		})
		return response
	} catch (error) {
		console.debug(error)
	}
}

const removeGuestFromConversation = async function(token, sessionId) {
	try {
		const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1', 2) + `room/${token}/participants/guests`, {
			params: {
				participant: sessionId,
			},
		})
		return response
	} catch (error) {
		console.debug(error)
	}
}

const promoteToModerator = async(token, options) => {
	const response = await axios.post(generateOcsUrl('apps/spreed/api/v1/room', 2) + token + '/moderators', options)
	return response
}

const demoteFromModerator = async(token, options) => {
	const response = await axios.delete(generateOcsUrl('apps/spreed/api/v1/room', 2) + token + '/moderators', {
		params: options,
	})
	return response
}

const fetchParticipants = async(token) => {
	const response = await axios.get(generateOcsUrl('apps/spreed/api/v1/room', 2) + token + '/participants')
	return response
}

export {
	joinConversation,
	leaveConversation,
	addParticipant,
	removeCurrentUserFromConversation,
	removeUserFromConversation,
	removeGuestFromConversation,
	promoteToModerator,
	demoteFromModerator,
	fetchParticipants,
}
