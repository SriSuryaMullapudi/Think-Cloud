
import Vue from 'vue'
import GeneralSettings from './views/AdminSettings/GeneralSettings'

Vue.prototype.t = t
Vue.prototype.n = n
Vue.prototype.OC = OC
Vue.prototype.OCA = OCA
Vue.prototype.OCP = OCP

export default new Vue({
	el: '#general_settings',
	name: 'GeneralSettings',
	render: h => h(GeneralSettings),
})
