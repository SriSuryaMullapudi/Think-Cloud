
import Vue from 'vue'
import StunServers from './views/AdminSettings/StunServers'

Vue.prototype.t = t
Vue.prototype.n = n
Vue.prototype.OC = OC
Vue.prototype.OCA = OCA
Vue.prototype.OCP = OCP

export default new Vue({
	el: '#stun_server',
	name: 'StunServerSettings',
	render: h => h(StunServers),
})
