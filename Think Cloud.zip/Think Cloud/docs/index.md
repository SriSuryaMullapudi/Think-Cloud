![Screenshot of the chat in Nextcloud Talk](chat.png)

# Nextcloud Talk API documentation


* [Constants](constants.md)
* [Capabilities](capabilities.md)
* [Conversation API](conversation.md)
* [Participant API](participant.md)
* [Call API](call.md)
* [Chat API](chat.md)
* [Signaling API](internal-signaling.md)
