module.exports = {
	extends: [
		'nextcloud'
	]
}
