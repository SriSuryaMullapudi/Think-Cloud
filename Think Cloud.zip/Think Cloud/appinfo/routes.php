<?php

return [
	'routes' => [
		[
			'name' => 'Page#index',
			'url' => '/',
			'verb' => 'GET',
		],
	],
	'ocs' => [
		
		[
			'name' => 'Signal#getSettings',
			'url' => '/api/{apiVersion}/signal/settings',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
			],
		],
		[
			'name' => 'Signal#backend',
			'url' => '/api/{apiVersion}/signal/backend',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
			],
		],
		[
			'name' => 'Signal#signal',
			'url' => '/api/{apiVersion}/signal/{token}',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Signaling#pullMessages',
			'url' => '/api/{apiVersion}/signaling/{token}',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],

		
		[
			'name' => 'Call#getPeersForCall',
			'url' => '/api/{apiVersion}/call/{token}',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Call#joinCall',
			'url' => '/api/{apiVersion}/call/{token}',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Call#leaveCall',
			'url' => '/api/{apiVersion}/call/{token}',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],

		
		[
			'name' => 'Chat#receiveMessages',
			'url' => '/api/{apiVersion}/chat/{token}',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Chat#sendMessage',
			'url' => '/api/{apiVersion}/chat/{token}',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Chat#setReadMarker',
			'url' => '/api/{apiVersion}/chat/{token}/read',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Chat#mentions',
			'url' => '/api/{apiVersion}/chat/{token}/mentions',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],

				[
			'name' => 'Room#getRooms',
			'url' => '/api/{apiVersion}/room',
			'verb' => 'GET',
			'requirements' => ['apiVersion' => 'v1'],
		],
		[
			'name' => 'Room#createRoom',
			'url' => '/api/{apiVersion}/room',
			'verb' => 'POST',
			'requirements' => ['apiVersion' => 'v1'],
		],
		[
			'name' => 'Room#getSingleRoom',
			'url' => '/api/{apiVersion}/room/{token}',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#renameRoom',
			'url' => '/api/{apiVersion}/room/{token}',
			'verb' => 'PUT',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#deleteRoom',
			'url' => '/api/{apiVersion}/room/{token}',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#makePublic',
			'url' => '/api/{apiVersion}/room/{token}/public',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#makePrivate',
			'url' => '/api/{apiVersion}/room/{token}/public',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#setReadOnly',
			'url' => '/api/{apiVersion}/room/{token}/read-only',
			'verb' => 'PUT',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#setPassword',
			'url' => '/api/{apiVersion}/room/{token}/password',
			'verb' => 'PUT',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#getParticipants',
			'url' => '/api/{apiVersion}/room/{token}/participants',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#addParticipantToRoom',
			'url' => '/api/{apiVersion}/room/{token}/participants',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#removeParticipantFromRoom',
			'url' => '/api/{apiVersion}/room/{token}/participants',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#removeSelfFromRoom',
			'url' => '/api/{apiVersion}/room/{token}/participants/self',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#removeGuestFromRoom',
			'url' => '/api/{apiVersion}/room/{token}/participants/guests',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#joinRoom',
			'url' => '/api/{apiVersion}/room/{token}/participants/active',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#leaveRoom',
			'url' => '/api/{apiVersion}/room/{token}/participants/active',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#promoteModerator',
			'url' => '/api/{apiVersion}/room/{token}/moderators',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#demoteModerator',
			'url' => '/api/{apiVersion}/room/{token}/moderators',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#addToFavorites',
			'url' => '/api/{apiVersion}/room/{token}/favorite',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#removeFromFavorites',
			'url' => '/api/{apiVersion}/room/{token}/favorite',
			'verb' => 'DELETE',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
		[
			'name' => 'Room#setNotificationLevel',
			'url' => '/api/{apiVersion}/room/{token}/notify',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],


		
		[
			'name' => 'PublicShareAuth#createRoom',
			'url' => '/api/{apiVersion}/publicshareauth',
			'verb' => 'POST',
			'requirements' => ['apiVersion' => 'v1'],
		],

		
		[
			'name' => 'FilesIntegration#getRoomByFileId',
			'url' => '/api/{apiVersion}/file/{fileId}',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'fileId' => '.+'
			],
		],
		[
			'name' => 'FilesIntegration#getRoomByShareToken',
			'url' => '/api/{apiVersion}/publicshare/{shareToken}',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
				'shareToken' => '.+',
			],
		],

		
		[
			'name' => 'Guest#setDisplayName',
			'url' => '/api/{apiVersion}/guest/{token}/name',
			'verb' => 'POST',
			'requirements' => [
				'apiVersion' => 'v1',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],

		
		[
			'name' => 'Command#index',
			'url' => '/api/{apiVersion}/command',
			'verb' => 'GET',
			'requirements' => [
				'apiVersion' => 'v1',
			],
		],

		
		[
			'name' => 'Webinar#setLobby',
			'url' => '/api/{apiVersion}/room/{token}/{webinar}/lobby',
			'verb' => 'PUT',
			'requirements' => [
				'apiVersion' => 'v1',
				'webinar' => 'webinary?',
				'token' => '^[a-z0-9]{4,30}$',
			],
		],
	],
];

