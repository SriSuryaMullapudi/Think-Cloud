<?php

$app = \OC::$server->query(\OCA\Think\AppInfo\Application::class);
// For the navigation $l->t('Think')
$app->register();
