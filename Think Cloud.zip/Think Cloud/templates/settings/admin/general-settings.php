<?php
/** @var array $_ */
/** @var \OCP\IL10N $l */
script('spreed', ['admin/general-settings']);
style('spreed', ['settings-admin']);
?>

<div class="videocalls section" id="general_settings">
	<h2><?php p($l->t('General settings')) ?></h2>
</div>
